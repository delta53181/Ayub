<?php
$conn=mysqli_connect("localhost","root","");
	mysqli_select_db($conn," ict_solution_and_comper_institute");
?>
<html>
<head>
<meta charset="utf-8">
<title> ছাত্র-ছাত্রীদের ভর্তি ফরম </title>
  <link rel="stylesheet" href="resources/demos/style.css">
  <script src="js/js1.js"></script>
  <script src="js/js2.js"></script>
  <script>
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true
    });
  } );
  </script>
<style>
*{
	margin: 0px; padding: 0px;
}
.company_title{
	width:1000px;
	height:37px;
	background-color:Green;
	margin: 0 auto;
	border-radius: 8px;
	border: 3px solid blue;
}
.student_information{
	background-color: Green;
    border: 3px solid blue;
    border-radius: 12px;
    height: 1200px;
    margin: 10px auto 0;
    padding-top: 20px;
    text-align: center;
    width: 1000px;
}
.company_title h1{
	color: white;
	text-align: center;
	font-size:30px;
	text-align:suttonyMJ;
}
.company_title h2{
	color: white;
	text-align: center;
	font-size:20px;
}
.company_title h3{
	color: white;
	text-align: center;
	font-size:20px;
}
.logo{
	width: 100px;
	height: 0px;
	margin-top: -15px;
	margin-left: 14px;
}
.delta{
	color: White;
	text-align: center;
	font-size:40px;
}
.bangabandhu{
	color: black;
	text-align: center;
	font-size:35px;
}
.kaliakoir{
	color: black;
	text-align: center;
	font-size:30px;
}
.asmission{
	color: red;
	text-align: center;
	font-size:40px;
}

.application{
	text-align: left;
	margin-top: 0px;
	margin-left: 5px;
	font-size: 25px;
}
.application1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	font-size: 16px;
}
.duration{
    border-radius: 10px;
    margin-top: -35px;
    margin-left: 602px;
    font-size: 23px;

}
.cours{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 220px;
	height: 35px;
	font-size: 16px;
}
.id_number{
	text-align: left;
	margin-top:10px;
	margin-left: 5px;
	font-size: 25px;
}
.id1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	font-size: 16px;
}
.Session{
	border-radius:10px;
	margin-top: -35px;
	margin-left: 612px;
	font-size: 25px;
}
.Session1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 220px;
	height: 35px;
	font-size: 16px;
}
.students_name{
    text-align: left;
	border-radius:10px;
	margin-top: 9px;
	font-size: 25px;
}
.s_name {
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	margin-left: 14px;
	margin-top: -28px;
	font-size: 16px;
}
.english{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	margin-left: 213px;
	margin-top: 0px;
	font-size: 16px;
}
.fathers_name{
	text-align: left;
    margin-top:10px;
	margin-left:5px;
	font-size: 25px;
}
.f_name{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	margin-left: 3px;
	margin-top: -28px;
	font-size: 16px;
}
.mothers_name{
	margin-left:-31px;
	margin-top: 10px;
	font-size: 25px;
}
.m_name{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	margin-left: -6px;
	margin-top: -28px;
	font-size: 16px;
}
.mailing_address{
	text-align: left;
    margin-top:10px;
	margin-left: 5px;
	font-size: 23px;
}
.m_address{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	margin-left: 8px;
	margin-top: -28px;
	font-size: 16px;
}
.permanent_address{
	text-align: left;
	margin-top:14px;
	margin-left: 5px;
	font-size: 20px;
}
.p_address{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	margin-left: 8px;
	margin-top: -28px;
	font-size: 16px;
}
.religion{
    text-align: left;
	margin-top:10px;
	margin-left: 5px;
	font-size: 25px;
}
.religion1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
	margin-left: 207px;
	margin-top: -30px;

}
.gender{
	border-radius: 10px;
    margin-top: -32px;
    font-size: 25px;
    width: 717px;
    margin-left: 315px;
}
.gender1{
	border: 2px;
    solid: black;
    border-radius: 7px;
    width: 240px;
    height: 35px;
    font-size: 16px;
    margin-top: -31px;
    margin-left: 345px;
}
.d_birth{
    margin-top: 10px;
    margin-left: 5px;
    font-size: 25px;
    text-align: left;
}
.class{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
	margin-left: 23px;
}
.b_group{
	border-radius: 10px;
    font-size: 25px;
    margin-top: -36px;
    width: 964px;
    text-align: left;
    margin-left: 566px;
}
.blood{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
}
.nationality{
	margin-top: 10px;
    margin-left: 5px;
    font-size: 25px;
    text-align: left;
}
.nationality1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
	margin-left: 43px;
}
.national_id{
	text-align: left;
    border-radius: 10px;
    margin-top: -37px;
    margin-left: 579px;
    font-size: 25px;
	}
.n_id{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
}
.mobile_number{
	margin-left: 5px;
    margin-top: 10px;
    font-size: 25px;
    text-align: left;
}
.m_number{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
}
.email{
	border-radius: 10px;
    margin-top: -37px;
    font-size: 25px;
    text-align: left;
    margin-left: 641px;
}
.e_phone{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
}
.G_P_name{
	border-radius: -31px;
    margin-top: 10px;
    font-size: 25px;
    text-align: left;
    margin-left: 5px;
}
.G_name{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 300px;
	height: 35px;
	margin-left: 14px;
	margin-top: -28px;
	font-size: 16px;
}
.occupation{
    border-radius: 10px;
    font-size: 25px;
    width: 717px;
    margin-top: -34px;
    margin-left: 293px;
}
.occupation1{
	border: 2px;
    solid: black;
    border-radius: 7px;
    width: 240px;
    height: 35px;
    font-size: 16px;
    margin-top: -29px;
    margin-left: 386px;
}
.relation{
    border-radius: -31px;
    margin-top: 10px;
    font-size: 25px;
    text-align: left;
    margin-left: 5px;
}
.relation1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	margin-left: 207px;
	margin-top: -28px;
	font-size: 16px;
}
.g_mobile_number{
    border-radius: 10px;
    font-size: 25px;
    width: 717px;
    margin-top: -35px;
    margin-left: 259px;
}
.g_m_number{
	border: 2px;
    solid: black;
    border-radius: 7px;
    width: 205px;
    height: 35px;
    font-size: 16px;
    margin-top: -29px;
    margin-left: 485px;
}
.g_address{
	margin-top: 10px;
    font-size: 25px;
    margin-left: 5px;
    text-align: left;
}
.g_address1{
	    border: 2px;
    solid: black;
    border-radius: 7px;
    width: 754px;
    height: 35px;
    margin-left: 103px;
    margin-top: -28px;
    font-size: 16px;
}
.accademic{
	text-align: left;
	margin-left: 5px;
	margin-top: 20px;
	font-size: 25px;
}
.examination{
	margin-top: 16px;
	margin-right: 770px;
	font-size: 20px;
}
.e_name{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 192px;
	height: 35px;
	font-size: 16px;
	margin-top: 7px;
}
.subject{
	margin-top: -65px;
	margin-right: 404px;
	font-size: 20px;
}
.s_group{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 161px;
	height: 35px;
	font-size: 16px;
	margin-top: 7px;
}
.board{
	margin-top: -65px;
	margin-right: 100px;
	font-size: 20px;
}
.board1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 130px;
	height: 35px;
	font-size: 16px;
	margin-top: 7px;
}
.year{
	margin-top: -65px;
	margin-right: -194px;
	font-size: 20px;
}
.year1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	font-size: 16px;
	margin-top: 7px;
}
.exam{
	margin-top: -65px;
	margin-right: -508px;
	font-size: 20px;
}
.exam1{
	order: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	font-size: 16px;
	margin-top: 7px;
}
.cgpa{
	margin-top: -65px;
	margin-right: -820px;
	font-size: 20px;
}
.cgpa1{
	order: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	font-size: 16px;
	margin-top: 7px;
}
.records{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 349px;
	height: 25px;
	margin-left: 135px;
	margin-top: -22px;
}
.photo_upload{
    padding-top: -5px;
    text-align: left;
	font-size: 25px;
	margin-top: -35px;
}
.photo upload{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 349px;
	height: 25px;
	
}
.date{
	text-align: right;
	border-radius: 10px;
	margin-top: -43px;
	margin-right: 28px;
	font-size: 25px;
}
.datepicker{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 138px;
	height: 35px;
	margin-top: 10px;
}
.btn {
    background-color: Red;
    margin-top: 11px;
    padding-bottom: 13px;
	height: 55px;
}

.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: black;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  cursor: pointer;
}

.button {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
  margin-right: 4px;
}

</style>
<body>
<section class="company_title">
<marquee>
<h1>আইসিটি সল্যুশন এন্ড কম্পিউটার ইন্সটিটিউট </h1>
</marquee>
</section>


<section class="student_information">
<form action="delta_a.php" Method="POST" cnctype="multipart/form-data" class="form_area">
	<div class="logo">
	<img src="delta 1.jpg" width="100px" height="100px" alt="ayub">
	</div>
	<div class="delta">
	<h1><center>ICT Solution and Computer Institute</center></h1>
	</div>
	<div class="bangabandhu">
	<h3><center>Bangabandhu Hi-Tech City</center></h3>
	</div>
	<div class="kaliakoir">
	<h4><center>Kaliakoir, Gazipur.</center></h4><br>
	</div>
	<div class="asmission">
	<center>Admission From</center>
	</div>
	<div class="application">
	<b>Application for Admission in :</b>

	<select class="application1" name="Admission_Name"> <option value="1"> Select </option>
									<option value="Basic Office Application">Basic Office Application</option>
									<option value="Responsiv Web Design">Responsiv Web Design</option>
									<option value="Web Development">Web Development</option>
									<option value="Graphics Design">Graphics Design</option>
									<option value="PHP + Laravel">PHP + Laravel</option>
									<option value="Wordpress Theme Customization">Wordpress Theme Customization</option>
									<option value="Software Development">Software Development</option>
									<option value="English Spoken">English Spoken</option>
									<option value="Others">Others</option>
													
											</select>
											</div>

	<div class="duration">
	<b>Duration :</b>
	<select class="cours" name="Cours_Duration"> <option value="1"> Select </option>
													<option value="2 Month">2 Month</option>
													<option value="3 Month">3 Month</option>
													<option value="5 Month">5 Month</option>
													<option value="6 Month">6 Month</option>
													<option value="1 years">1 years</option>
													<option value="২ মাস">২ মাস</option>
													<option value="৩ মাস">৩ মাস</option>
													<option value="৫ মাস">৫ মাস</option>
													<option value="৬ মাস">৬ মাস</option>
													<option value="১ বছর">১ বছর</option>
													
											</select>
											</div>

	<div class="id_number">
	<b>ID Number :</b> <input class="id1" type="text" name="ID_Number" placeholder="আইডির নাম্বার">
	</div>
	<div class="Session">
	<b>Session :</b> <input class="Session1" type="text" name="Session" placeholder="সেশন">
	</div>
	<div class="students_name">
	<b>1. Student Name   :</b> <input class="s_name" type="text" name="Students_Bangla_Name" placeholder="বাংলায় নাম">
	</div>
	<div class="students_name">
	<input class="english" type="text" name="Students_English_Name" placeholder="ইংরেজীতে নাম">
	</div>
	<div class="fathers_name">
	<b>2. Father᾿s Name :</b> <input class="f_name" type="text" name="Fathers_Bangla_name" placeholder="বাংলায় নাম">
	</div>
	<div class="students_name">
	<input class="english" type="text" name="Fathers_English_name" placeholder="ইংরেজীতে নাম">
	</div>
	<div class="mothers_name">
	<b>3. Mother᾿s Name :</b> <input class="m_name" type="text" name="Mothers_Bangla_name" placeholder="বাংলায় নাম">
	</div>
	<div class="students_name">
	<input class="english" type="text" name="Mothers_English_name" placeholder="ইংরেজীতে নাম">
	</div>
	<div class="mailing_address">
	<b>4. Mailing Address :</b><input class="m_address" type="text" name="Mailing_Address" placeholder="বর্তমান ঠিকানা">
	</div>
	<div class="permanent_address">
	<b>5. Permanent Address :</b><input class="p_address" type="text" name="Permanent_Address" placeholder="স্থায়ী ঠিকানা">
	</div>
	<div class="religion">
	<b>6. Religion :</b><br>

	<select class="religion1" name="Religion"> <option value="1"> Select </option>
													<option value="Islam">Islam</option>
													<option value="Hinduism">Hinduism</option>
													<option value="Christianity">Christianity</option>
													<option value="Buddhism">Buddhism</option>
													<option value="Others">Others</option>
													
											</select>
											</div>

	<div class="gender">
	<b>Gender :</b><br>
	<select class="gender1" name="Gender"> <option value="1"> Select </option>
													<option value="Male">Male</option>
													<option value="Female">Female</option>
													<option value="Others">Others</option>
													
											</select>
											</div>
											
	<div class="d_birth">
	<b>7. Date of Birth :</b> <input class="class" type="text" name="Date_of_Birth" placeholder="জন্ম তারিখ">
	</div>
	<div class=b_group>
	<b>Blood Group :</b> <input class="blood" type="text" name="Blood_Group" placeholder="রক্তের গ্রুপ">
	</div>
	<div class="nationality">
	<b>8. Nationality :</b> <input class="nationality1" type="text" name="Nationality" placeholder="জাতীয়তা">
	</div>
	<div class="national_id">
	<b>National ID :</b> <input class="n_id" type="text" name="National_ID_Number" placeholder="জাতীয় পরিচয় পত্রের নাম্বার">
	</div>
	<div class="mobile_number">
	<b>9. Phone Number :</b> <input class="m_number" type="text" name="Phone_Number" placeholder="মোবাইল নাম্বার">
	</div>	
	<div class="email">
	<b>Email :</b> <input class="e_phone" type="text" name="Email_Address" placeholder="ইমেল আইডি">
	</div>
	<div class="G_P_name">
	<b>Guardian Name   :</b> <input class="G_name" type="text" name="Guardian_Present_Name" placeholder="বাংলায় নাম">
	</div>
	<div class="occupation">
	<b>Occupation :</b><br>

	<select class="Occupation1" name="Occupation"> <option value="1"> Select </option>
													<option value="Govt.Job">Govt.Job</option>
													<option value="Private Job</">Private Job</option>
													<option value="House Wife">House Wife</option>
													<option value="Farmer">Farmer</option>
													<option value="Business">Business</option>
													
											</select>
											</div>
	<div class="relation">
	<b>Relation :</b><br>

	<select class="Relation1" name="Relation"> <option value="1"> Select </option>
													<option value="Father">Father</option>
													<option value="Mother">Mother</option>
													<option value="Sister">Sister</option>
													<option value="Brother">Brother</option>
													<option value="Uncle/Aunty">Uncle/Aunty</option>
													
											</select>
											</div>
	<div class="g_mobile_number">
	<b>Gurdian Phone Number :</b> <input class="g_m_number" type="text" name="Gurdian_Phone_Number" placeholder="মোবাইল নাম্বার">
	</div>	
	<div class="g_address">
	<b>Address :</b><input class="g_address1" type="text" name="Gurdian_Address" placeholder="বর্তমান ঠিকানা">
	</div>
	<div class="accademic">
	<b>10. Academic Information (Please mention latest degree only):</b>
	</div>
	<div class="examination">
	<b>Examination Name</b><br>
	<select class="e_name" name="Examination_Name"> <option value="1"> Select </option>
													<option value="S.S.C">S.S.C</option>
													<option value="H.S.C">H.S.C</option>
													<option value="B.A (Pass Course)">B.A (Pass Course)</option>
													<option value="B.S.S (Pass Course)">B.S.S (Pass Course)</option>
													<option value="B.Sc (Pass Course)">B.Sc (Pass Course)</option>
													<option value="B.Com (Pass Course)">B.Com (Pass Course)</option>
													<option value="L.L.B (Pass Course)">L.L.B (Pass Course)</option>
													<option value="B.Com (Honors)">B.Com (Honors)</option>
													<option value="Honors">Honors</option>
													<option value="BBS">BBS</option>
													<option value="BBS (Pass Course)">BBS (Pass Course)</option>
													<option value="Fazil">Fazil</option>
													<option value="Dakhil">Dakhil</option>
													<option value="B.S.S (Honors)">B.S.S (Honors)</option>
													<option value="B.Sc (Honors)">B.Sc (Honors)</option>
													<option value="B.A (Honors)">B.A (Honors)</option>
													<option value="B.Sc">B.Sc</option>
													<option value="LL.B.(Honours)">LL.B.(Honours)</option>
													<option value="B.Sc (Agricultural Science)">B.Sc (Agricultural Science)</option>
													
											</select>
											</div>	
	<div class="subject">
	<b>Subject Group</b><br>
	<select class="s_group" name="Subject_Group"> <option value="1"> Select </option>
											<option value="Science">Science</option>
											<option value="Humanities">Humanities</option>
											<option value="Business Studies">Business Studies</option>
											<option value="Agriculture Technology">Agriculture Technology</option>
											<option value="Automobile Technology">Automobile Technology</option>
											<option value="Electrical Technology">Electrical Technology</option>
											<option value="Air Conditioning Technology">Air Conditioning Technology</option>
											<option value="Telecommunication Technology">Telecommunication Technology</option>
											<option value="Electronics Technology">Electronics Technology</option>
											<option value="Textile Technology">Textile Technology</option>
	
											</select>
											</div>	
	
	<div class="board">
	<b>Board</b><br>
	
	<select class="board1" name="Board"> <option value="1"> Select </option>
													<option value="Dhaka">Dhaka</option>
													<option value="Cumilla">Cumilla</option>
													<option value="Rajshahi">Rajshahi</option>
													<option value="Jashore">Jashore</option>
													<option value="Chittagong">Chittagong</option>
													<option value="Barishal">Barishal</option>
													<option value="Sylhet">Sylhet</option>
													<option value="Dinajpur">Dinajpur</option>
													<option value="Madrasah">Madrasah</option>
													<option value="Technical">Technical</option>
	
											</select>
											</div>	
	<div class="year">
	<b>Passing Year</b><br>
	<select class="year1" name="Passing_Year"> <option value="1"> Select </option>
													<option value="1970">1970</option>
													<option value="1970">1970</option>
													<option value="1971">1971</option>
													<option value="1972">1972</option>
													<option value="1973">1973</option>
													<option value="1974">1974</option>
													<option value="1975">1975</option>
													<option value="1976">1976</option>
													<option value="1977">1977</option>
													<option value="1978">1978</option>
													<option value="1979">1979</option>
													<option value="1980">1980</option>
													<option value="1981">1981</option>
													<option value="1982">1982</option>
													<option value="1983">1983</option>
													<option value="1984">1984</option>
													<option value="1985">1985</option>
													<option value="1986">1986</option>
													<option value="1987">1987</option>
													<option value="1988">1988</option>
													<option value="1989">1989</option>
													<option value="1990">1990</option>
													<option value="1991">1991</option>
													<option value="1992">1992</option>
													<option value="1993">1993</option>
													<option value="1994">1994</option>
													<option value="1995">1995</option>
													<option value="1996">1996</option>
													<option value="1997">1997</option>
													<option value="1998">1998</option>
													<option value="1999">1999</option>
													<option value="2000">2000</option>
													<option value="2001">2001</option>
													<option value="2002">2002</option>
													<option value="2003">2003</option>
													<option value="2004">2004</option>
													<option value="2005">2005</option>
													<option value="2006">2006</option>
													<option value="2007">2007</option>
													<option value="2008">2008</option>
													<option value="2009">2009</option>
													<option value="2010">2010</option>
													<option value="2011">2011</option>
													<option value="2012">2012</option>
													<option value="2013">2013</option>
													<option value="2014">2014</option>
													<option value="2015">2015</option>
													<option value="2016">2016</option>
													<option value="2017">2017</option>
													<option value="2018">2018</option>
													<option value="2019">2019</option>
													
										</select>
										</div>	
	<div class="exam">
	<b>Roll of Exam</b><br><input class="exam1" type="text" name="Roll_Exam" placeholder="Roll of Exam">
	</div>	
	<div class="cgpa">
	<b>Division/GPA</b><br><input class="cgpa1" type="text" name="Division" placeholder="Division/GPA">
	</div><br><br><br>	
	<div class="photo_upload">
	<b>Photo Upload</b> <input class="photo upload" type="file" name="Student_Photo" value="photo upload">
	</div>
	<div class="date">
	<b>Date :</b> <input class="datepicker" type="date" name="Admission_Date" placeholder="তারিখ">
	</div>
	<div class="btn">
	<input type="submit" class="button" name="submit" value="Save">
	
	</div>
</body>
</head>

</html>
<?php
if(isset($_POST["submit"]))
{
	mysqli_query($conn,"insert into students_admission value ('$_POST[Admission_Name]','$_POST[Cours_Duration]','$_POST[ID_Number]','$_POST[Session]','$_POST[Students_Bangla_Name]','$_POST[Students_English_Name]','$_POST[Fathers_Bangla_name]','$_POST[Fathers_English_name]','$_POST[Mothers_Bangla_name]','$_POST[Mothers_English_name]','$_POST[Mailing_Address]','$_POST[Permanent_Address]','$_POST[Religion]','$_POST[Gender]','$_POST[Date_of_Birth]','$_POST[Blood_Group]','$_POST[Nationality]','$_POST[National_ID_Number]','$_POST[Phone_Number]','$_POST[Email_Address]','$_POST[Examination_Name]','$_POST[Subject_Group]','$_POST[Board]','$_POST[Passing_Year]','$_POST[Roll_Exam]','$_POST[Division]','$_POST[Guardian_Present_Name]','$_POST[Occupation]','$_POST[Relation]','$_POST[Gurdian_Phone_Number]','$_POST[Gurdian_Address]','$_POST[Student_Photo]','$_POST[Admission_Date]')");
}
?>