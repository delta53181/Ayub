<html>
<head>
<meta charset="utf-8">
<title> Student Admission </title>
<link type="text/css" rel="stylesheet" href="style4.css"></link>
<link rel="stylesheet" href="css/css1.css">
  <link rel="stylesheet" href="resources/demos/style.css">
  <script src="js/js1.js"></script>
  <script src="js/js2.js"></script>
  <script>
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true
    });
  } );
  </script>
<style>
*{
	margin: 0px; padding: 0px;
}
.company_title{
	width:1000px;
	height:37px;
	background-color:Green;
	margin: 0 auto;
	border-radius: 8px;
	border: 3px solid blue;
}
.student_information{
	background-color: -moz-menuhover;
    border: 3px solid blue;
    border-radius: 12px;
    height: 1200px;
    margin: 10px auto 0;
    padding-top: 20px;
    text-align: center;
    width: 1000px;
}
.company_title h1{
	color: white;
	text-align: center;
	font-size:30px;
	text-align:suttonyMJ;
}
.company_title h2{
	color: white;
	text-align: center;
	font-size:20px;
}
.company_title h3{
	color: white;
	text-align: center;
	font-size:20px;
}
.logo{
	width: 100px;
	height: 0px;
	margin-top: -15px;
	margin-left: 14px;
}
.delta{
	color: black;
	text-align: center;
	font-size:35px;
}
.bangabandhu{
	color: black;
	text-align: center;
	font-size:35px;
}
.kaliakoir{
	color: black;
	text-align: center;
	font-size:30px;
}
.asmission{
	color: red;
	text-align: center;
	font-size:40px;
	text-align:suttonyMJ;
}

.application{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left: 2px;
	margin-left:-31px;
	font-size: 25px;
}
.application1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 340px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
}
.id_number{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left: 2px;
	margin-left:-31px;
	font-size: 25px;
}
.id1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
}
.Session{
	padding-left: 10px;
    text-align: right;
	border-radius:10px;
	margin-top: -25px;
	margin-left: 40px;
	margin-right: 25px;
	font-size: 25px;
}
.Session1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
}
.students_name{
	padding-left: 10px;
    text-align: left;
	border-radius:10px;
	margin-top: 9px;
	font-size: 25px;
}
.s_name {
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	padding-left: 7px;
	margin-left: 14px;
	margin-top: -28px;
	font-size: 16px;
	font-size: 16px;
}
.english{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	padding-left: 7px;
	margin-left: 210px;
	margin-top: 0px;
	font-size: 16px;
}
.fathers_name{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left:-31px;
	margin-top: 0px;
	font-size: 25px;
}
.f_name{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	padding-left: 7px;
	margin-left: 3px;
	margin-top: -28px;
	font-size: 16px;
}
.mothers_name{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left:-31px;
	margin-top: 0px;
	font-size: 25px;
}
.m_name{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	padding-left: 7px;
	margin-left: -6px;
	margin-top: -28px;
	font-size: 16px;
}
.mailing_address{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left:-31px;
	font-size: 23px;
}
.m_address{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	padding-left: 7px;
	margin-left: 8px;
	margin-top: -28px;
	font-size: 16px;
}
.permanent_address{
	padding-left: 44px;
    padding-top: 0px;
    text-align: left;
	margin-left: 17px;
	margin-left:-31px;
	font-size: 20px;
	margin-top:13px;
}
.p_address{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	padding-left: 7px;
	margin-left: 8px;
	margin-top: -28px;
	font-size: 16px;
}
.religion{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left:-31px;
	font-size: 25px;
}
.religion1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 75px;
}
.gender{
	padding-left: 10px;
	text-align: right;
	border-radius: 10px;
	margin-top: -25px;
	margin-right: 16px;
	margin-right: 14px;
	font-size: 25px;
	margin-top: -36px;
	width: 964px;
}
.gender1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
}
.d_birth{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left:-31px;
	font-size: 25px;
}
.class{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 23px;
}
.b_group{
	padding-left: 10px;
	text-align: right;
	border-radius: 10px;
	margin-top: -25px;
	margin-right: 16px;
	margin-right: 14px;
	font-size: 25px;
	margin-top: -36px;
	width: 964px;
}
.blood{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
}
.nationality{
	padding-left: 44px;
	padding-top: 14px;
	text-align: left;
	margin-left: -31px;
	margin-top: -7px;
	font-size: 25px;
	margin-top: -7px;
}
.nationality1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 43px;
}
.national_id{
	padding-left: 10px;
	text-align: right;
	border-radius: 10px;
	margin-top: -37px;
	margin-right: 16px;
	margin-right: 27px;
	font-size: 25px;
	}
.n_id{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
}
.mobile_number{
	padding-left: 44px;
	padding-top: 14px;
	text-align: left;
	margin-left: -31px;
	margin-top: -7px;
	font-size: 25px;
	margin-top: -7px;
}
.m_number{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
}
.email{
	padding-left: 10px;
	text-align: right;
	border-radius: 10px;
	margin-top: -37px;
	margin-right: 27px;
	font-size: 25px;
}
.e_phone{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
}
.accademic{
	padding-left: 44px;
	padding-top: 14px;
	text-align: left;
	margin-left: -31px;
	margin-top: -7px;
	font-size: 25px;
	margin-top: -7px;
}
.examination{
	margin-top: 16px;
	margin-right: 770px;
	font-size: 20px;
}
.e_name{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 192px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-top: 7px;
}
.subject{
	margin-top: -65px;
	margin-right: 404px;
	font-size: 20px;
}
.s_group{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 161px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-top: 7px;
}
.board{
	margin-top: -65px;
	margin-right: 100px;
	font-size: 20px;
}
.board1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 130px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-top: 7px;
}
.year{
	margin-top: -65px;
	margin-right: -194px;
	font-size: 20px;
}
.year1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-top: 7px;
}
.exam{
	margin-top: -65px;
	margin-right: -508px;
	font-size: 20px;
}
.exam1{
	order: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-top: 7px;
}
.cgpa{
	margin-top: -65px;
	margin-right: -820px;
	font-size: 20px;
}
.cgpa1{
	order: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-top: 7px;
}
.records{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 349px;
	height: 25px;
	padding-left: 7px;
	margin-left: 135px;
	margin-top: -22px;
}
.S_Signature{
	margin-top: 30px;
	margin-right: 154px;
	font-size: 25px;
	}
.G_Signature{
	margin-left: 719px;
	margin-top: -27px;
	font-size: 25px;
}
.photo_upload{
	padding-left: 44px;
    padding-top: -5px;
    text-align: left;
	margin-left: 17px;
	margin-left: 2px;
	margin-left:-31px;
	font-size: 25px;
}
.photo upload{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 349px;
	height: 25px;
	padding-left: 7px;
	margin-left: 135px;
	margin-top: -22px;
}
.date{
	padding-left: 10px;
	text-align: right;
	border-radius: 10px;
	margin-top: -25px;
	margin-right: 28px;
	font-size: 25px;
}
.datepicker{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 138px;
	height: 35px;
	padding-left: 7px;
	margin-top: 10px;
}
.btn {
    padding-top: 1px;
    background-color: Red;
    background-color: Rad;
    margin-top: 11px;
    padding-bottom: 13px;
	height: 55px;
}
.ayub {
    font-size: 20px;
    padding: 10px;
    color: blue;
}
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: black;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
  margin-right: 4px;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}

.button3 {
  background-color: white; 
  color: black; 
  border: 2px solid #f44336;
}

.button3:hover {
  background-color: #f44336;
  color: white;
}
.button5 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
}

.button4:hover {
  background-color: #555555;
  color: white;
}

</style>
<body>
<section class="company_title">
<marquee>
<h1>ডেলটা কম্পিউটার ট্রেনিং ইনষ্টিটিউট </h1>
</marquee>
</section>


<section class="student_information">
<form action="Student_Information_final.php" Method="POST" cnctype="multipart/form-data" class="form_area">
	<div class="logo">
	<img src="delta.jpg" width="100px" height="100px" alt="ayub">
	</div>
	<div class="delta">
	<h1><center>Delta Computer Traning Institute</center></h1>
	</div>
	<div class="bangabandhu">
	<h3><center>Bangabandhu Hi-Tech City</center></h3>
	</div>
	<div class="kaliakoir">
	<h4><center>Kaliakoir, Gazipur.</center></h4><br>
	</div>
	<div class="asmission">
	<center>Admission From</center>
	</div>
	<div class="application">
	<b>Application for Admission in :</b> <input class="application1" type="text" name="Application" placeholder="কোর্সের নাম">
	</div>
	<div class="id_number">
	<b>ID Number :</b> <input class="id1" type="text" name="ID_Number" placeholder="আইডির নাম্বার">
	</div>
	<div class="Session">
	<b>Session :</b> <input class="Session1" type="text" name="Session" placeholder="সেশন">
	</div>
	<div class="students_name">
	<b>1. Student Name   :</b> <input class="s_name" type="text" name="students_name" placeholder="বাংলায় নাম">
	</div>
	<div class="students_name">
	<input class="english" type="text" name="students_name" placeholder="ইংরেজীতে নাম">
	</div>
	<div class="fathers_name">
	<b>2. Father᾿s Name :</b> <input class="f_name" type="text" name="fathers_name" placeholder="বাংলায় নাম">
	</div>
	<div class="students_name">
	<input class="english" type="text" name="students_name" placeholder="ইংরেজীতে নাম">
	</div>
	<div class="mothers_name">
	<b>3. Mother᾿s Name :</b> <input class="m_name" type="text" name="mothers_name" placeholder="বাংলায় নাম">
	</div>
	<div class="students_name">
	<input class="english" type="text" name="students_name" placeholder="ইংরেজীতে নাম">
	</div>
	<div class="mailing_address">
	<b>4. Mailing Address :</b><input class="m_address" type="text" name="fathers_name" placeholder="বর্তমান ঠিকানা">
	</div>
	<div class="permanent_address">
	<b>5. Permanent Address :</b><input class="p_address" type="text" name="fathers_name" placeholder="স্থায়ী ঠিকানা">
	</div>
	<div class="religion">
	<b>6. Religion :</b> <input class="religion1" type="text" name="date of birth" placeholder="ধর্ম">
	</div>
	<div class="gender">
	<b>Gender :</b>
	<input class="gender1" type="text" name="gender" placeholder="পুরুষ / মহিলা">
	</div>
	<div class="d_birth">
	<b>7. Date of Birth :</b> <input class="class" type="text" name="class" placeholder="জন্ম তারিখ">
	</div>
	<div class=b_group>
	<b>Blood Group :</b> <input class="blood" type="text" name="roll" placeholder="রক্তের গ্রুপ">
	</div>
	<div class="nationality">
	<b>8. Nationality :</b> <input class="nationality1" type="text" name="section" placeholder="জাতীয়তা">
	</div>
	<div class="national_id">
	<b>National ID :</b> <input class="n_id" type="text" name="nationalty" placeholder="জাতীয় পরিচয় পত্রের নাম্বার">
	</div>
	<div class="mobile_number">
	<b>9. Phone Number :</b> <input class="m_number" type="text" name="mobile_number" placeholder="মোবাইল নাম্বার">
	</div>	
	<div class="email">
	<b>Email :</b> <input class="e_phone" type="text" name="present_address" placeholder="ইমেল আইডি">
	</div>
	<div class="accademic">
	<b>10. Academic Information (Please mention latest degree only):</b>
	</div>
	<div class="examination">
	<b>Examination Name</b><br>
	<select class="e_name" name="Examination_Name"> <option value="1"> Select </option>
													<option value="S.S.C">S.S.C</option>
													<option value="H.S.C">H.S.C</option>
													<option value="Bachelor (Horns)pass">Bachelor (Horns)pass</option>
													<option value="Masters">Masters</option>
													<option value="Others">Others</option>
													
	
	
	</select>
	</div>	
	<div class="subject">
	<b>Subject Group</b><br><input class="s_group" type="text" name="Subject_Group" placeholder="Subject Group">
	</div>	
	<div class="board">
	<b>Board</b><br><input class="board1" type="text" name="Board" placeholder="Board">
	</div>	
	<div class="year">
	<b>Passing Year</b><br><input class="year1" type="text" name="Passing_Year" placeholder="Passing Year">
	</div>	
	<div class="exam">
	<b>Roll of Exam</b><br><input class="exam1" type="text" name="Roll_Exam" placeholder="Roll of Exam">
	</div>	
	<div class="cgpa">
	<b>Division/GPA</b><br><input class="cgpa1" type="text" name="Division" placeholder="Division/GPA">
	</div><br><br><br>	
	<div class="S_Signature">
	<b>Student Signature</b>
	</div>
	<div class="G_Signature">
	<b>Guardian Signature</b>
	</div>
	<div class="photo_upload">
	<b>Photo Upload</b> <input class="photo upload" type="file" name="image" value="photo upload">
	</div>
	<div class="date">
	<b>Date :</b> <input class="datepicker" type="date" name="date" placeholder="তারিখ">
	</div>
	<div class="btn">
	<button class="button button1">Save</button>
<button class="button button2">Delete</button>
<button class="button button3">Update</button>
<button class="button button4">Show</button>

	</div>
</body>
</head>

</html>