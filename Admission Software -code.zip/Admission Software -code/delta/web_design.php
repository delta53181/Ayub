
<!DOCTYPE lang="en-US">
    <html>

    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="UTF-8">
		
        <title>ওয়ার্ডপ্রেস অনলাইন কোর্স &#8211; Delta Institute of Technology</title>
<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/softtech-it.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.15"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='http://softtech-it.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='fb-messenger-style-css'  href='http://softtech-it.com/wp-content/plugins/fb-messenger/css/style.css?ver=4.9.15' type='text/css' media='all' />
<link rel='stylesheet' id='wp-video-grid-lighbox-style-css'  href='http://softtech-it.com/wp-content/plugins/video-grid/css/wp-video-grid-lighbox-style.css?ver=4.9.15' type='text/css' media='all' />
<link rel='stylesheet' id='vl-box-grid-css-css'  href='http://softtech-it.com/wp-content/plugins/video-grid/css/vl-box-grid-css.css?ver=4.9.15' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='http://softtech-it.com/wp-content/themes/SoftTechIT/css/bootstrap.min.css?ver=4.9.15' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='http://softtech-it.com/wp-content/themes/SoftTechIT/css/font-awesome.min.css?ver=4.9.15' type='text/css' media='all' />
<link rel='stylesheet' id='softtechit-stylesheet-css'  href='http://softtech-it.com/wp-content/themes/SoftTechIT/style.css?ver=4.9.15' type='text/css' media='all' />
<link rel='stylesheet' id='rpt-css'  href='http://softtech-it.com/wp-content/plugins/dk-pricr-responsive-pricing-table/inc/css/rpt_style.min.css?ver=4.9.15' type='text/css' media='all' />
<script type='text/javascript' src='http://softtech-it.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/plugins/video-grid/js/vl-grid-js.js?ver=4.9.15'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/plugins/video-grid/js/v_grid.js?ver=4.9.15'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/themes/SoftTechIT/js/jquery-ui.min.js?ver=4.9.15'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/themes/SoftTechIT/js/custom.js?ver=4.9.15'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/plugins/dk-pricr-responsive-pricing-table/inc/js/rpt.min.js?ver=4.9.15'></script>
<link rel='https://api.w.org/' href='http://softtech-it.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://softtech-it.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://softtech-it.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.15" />
<link rel="canonical" href="http://softtech-it.com/online-course/" />
<link rel='shortlink' href='http://softtech-it.com/?p=18' />
<link rel="alternate" type="application/json+oembed" href="http://softtech-it.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fsofttech-it.com%2Fonline-course%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://softtech-it.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fsofttech-it.com%2Fonline-course%2F&#038;format=xml" />
			<meta property="fb:pages" content="1532418280146533" />
			<link rel="apple-touch-icon" sizes="180x180" href="/wp-content/uploads/fbrfg/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/wp-content/uploads/fbrfg/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/wp-content/uploads/fbrfg/favicon-16x16.png">
<link rel="manifest" href="/wp-content/uploads/fbrfg/site.webmanifest">
<link rel="mask-icon" href="/wp-content/uploads/fbrfg/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" href="/wp-content/uploads/fbrfg/favicon.ico">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="msapplication-config" content="/wp-content/uploads/fbrfg/browserconfig.xml">
<meta name="theme-color" content="#ffffff">
<!-- WordPress Facebook Integration Begin -->

<script type='text/javascript'>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
</script>

<script>
fbq('init', '212884919066594', {}, {
    "agent": "wordpress-4.9.15-1.7.7"
});

fbq('track', 'PageView', {
    "source": "wordpress",
    "version": "4.9.15",
    "pluginVersion": "1.7.7"
});
</script>
<!-- DO NOT MODIFY -->
<!-- WordPress Facebook Integration end -->
    
<!-- Facebook Pixel Code -->
<noscript>
<img height="1" width="1" style="display:none" alt="fbpx"
src="https://www.facebook.com/tr?id=212884919066594&ev=PageView&noscript=1"/>
</noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->
    
<!-- BEGIN ExactMetrics v5.3.5 Universal Analytics - https://exactmetrics.com/ -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-118259182-1', 'auto');
  ga('send', 'pageview');
</script>
<!-- END ExactMetrics Universal Analytics -->
    </head>

    <body class="page-template page-template-fullwidth-page page-template-fullwidth-page-php page page-id-18" >
	
		    <div class="sticky-header fixed">
        <div class="container">
            <div class="container row">
                <div class="col-md-3">
                    <div class="logo">
                         <a href="http://softtech-it.com"> <img src="http://softtech-it.com/wp-content/uploads/2018/02/softtech-it-white.png" alt="Logo"> </a>
                        <a class="menu-bar"> <i class="fa fa-bars"> </i> </a>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="main-menu">

                        <div class="menu-main-menu-container"><ul id="menu-main-menu" class="menu"><li id="menu-item-7" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-7"><a href="http://softtech-it.com/">হোম</a></li>
<li id="menu-item-26" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-26"><a href="http://softtech-it.com/about-us/">আমাদের সম্পর্কে</a></li>
<li id="menu-item-24" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children menu-item-24"><a href="#">কোর্সসমূহ</a>
<ul class="sub-menu">
	<li id="menu-item-21" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="http://softtech-it.com/wordpress-course-in-bangladesh/">অ্যাডভান্সড ওয়ার্ডপ্রেস ডেভেলপমেন্ট</a></li>
	<li id="menu-item-130" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-130"><a href="http://softtech-it.com/graphic-design-course-in-bangladesh/">প্রফেশনাল ক্রিয়েটিভ গ্রাফিক ডিজাইন</a></li>
	<li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-18 current_page_item menu-item-20"><a href="http://softtech-it.com/online-course/">ওয়ার্ডপ্রেস অনলাইন কোর্স</a></li>
</ul>
</li>
<li id="menu-item-23" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-23"><a href="http://softtech-it.com/seminar/">সেমিনার</a></li>
<li id="menu-item-158" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-158"><a href="http://softtech-it.com/%e0%a6%b8%e0%a7%87%e0%a6%ac%e0%a6%be-%e0%a6%b8%e0%a6%ae%e0%a7%82%e0%a6%b9/">সেবা সমূহ</a>
<ul class="sub-menu">
	<li id="menu-item-160" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-160"><a href="http://softtech-it.com/web-design-in-bangladesh/">ওয়েবসাইট ডেভেলপমেন্ট</a></li>
</ul>
</li>
<li id="menu-item-22" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22"><a href="http://softtech-it.com/contact/">যোগাযোগ</a></li>
<li id="menu-item-60" class="active menu-item menu-item-type-post_type menu-item-object-page menu-item-60"><a href="http://softtech-it.com/successful-freelancers-in-bangladesh/">সফল যারা</a></li>
</ul></div>                    </div>
                </div>
            </div>
        </div>
    </div>
	

        <!-- Header Area -->
        <div class="header-area-bg-single">
            <div class="header-area-single">
                <div class="top-area">
            <div class="container">
                <div class="top-content">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="top-content-one top-content-icon">
                                <p> <i class="fa fa-wordpress"></i> ১৮০৮ এবং ১৮০৯ তম ব্যাচে ভর্তি চলছে  </p> <span> </span>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="top-content-two top-content-icon">
                                <p> <i class="fa fa-map-marker"></i> সকাল ০৯.০০ - বিকাল ০৫.০০ (অফিস)  </p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="top-content-three top-content-icon">
                                <p> <i class="fa fa-phone-square"></i> ০১৩১৯-৫১১০০৮, ০১৩১৯-৫১১০০৯  </p>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="top-social-icons">
                                <ul>
                                    <li><a title="Facebook Page" target="_blank" href="http://facebook.com/softtechitinstitute"> <i class="fa fa-facebook"></i> </a></li>
                                    <li><a title="Twitter Profile" target="_blank" href="http://twitter.com/softtechitinst"> <i class="fa fa-twitter"></i> </a></li>
                                    <li><a title="Linkedin Profile" target="_blank" href="#"> <i class="fa fa-linkedin"></i> </a></li>
                                    <li><a title="Youtube Channel" target="_blank" href="http://youtube.com/softtechit"> <i class="fa fa-youtube"></i> </a></li>
                                    <li><a title="Facebook Group" target="_blank" href="http://facebook.com/groups/softtechit"> <i class="fa fa-facebook-square"></i> </a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                <div class="header-content">
                    <div class="container">
                        <div class="header-main">
                            <div class="header-content">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="logo">
                                           
											 <a href="http://softtech-it.com"> <img src="delta 1.jpg" alt="Logo"> </a>
                                            <a class="menu-bar"> <i class="fa fa-bars"> </i> </a>
                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="main-menu">

                                            <div class="menu-main-menu-container"><ul id="menu-main-menu-1" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-7"><a href="http://softtech-it.com/">হোম</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-26"><a href="http://softtech-it.com/about-us/">আমাদের সম্পর্কে</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children menu-item-24"><a href="#">কোর্সসমূহ</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="http://softtech-it.com/wordpress-course-in-bangladesh/">অ্যাডভান্সড ওয়ার্ডপ্রেস ডেভেলপমেন্ট</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-130"><a href="http://softtech-it.com/graphic-design-course-in-bangladesh/">প্রফেশনাল ক্রিয়েটিভ গ্রাফিক ডিজাইন</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-18 current_page_item menu-item-20"><a href="http://softtech-it.com/online-course/">ওয়ার্ডপ্রেস অনলাইন কোর্স</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-23"><a href="http://softtech-it.com/seminar/">সেমিনার</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-158"><a href="http://softtech-it.com/%e0%a6%b8%e0%a7%87%e0%a6%ac%e0%a6%be-%e0%a6%b8%e0%a6%ae%e0%a7%82%e0%a6%b9/">সেবা সমূহ</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-160"><a href="http://softtech-it.com/web-design-in-bangladesh/">ওয়েবসাইট ডেভেলপমেন্ট</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22"><a href="http://softtech-it.com/contact/">যোগাযোগ</a></li>
<li class="active menu-item menu-item-type-post_type menu-item-object-page menu-item-60"><a href="http://softtech-it.com/successful-freelancers-in-bangladesh/">সফল যারা</a></li>
</ul></div>                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Header Area -->

<div class="single-page-area">
	<div class="container">
							<div class="single-page">
						<div class="single-page-title">
							<h2>
								<a href="http://softtech-it.com/online-course/"> ওয়ার্ডপ্রেস অনলাইন কোর্স </a>
							</h2>
							<h3>
								<p class="text-danger text-center">ট্রেইনারঃ মোঃ সালাহ উদ্দিন শিপনু | মোট ক্লাসঃ ৭১ টি | কোর্স ফিঃ ১৫০০০ টাকা</p>							</h3>
						</div>
						<p>ডেলটা ইনষ্টিটিউট অফ টেকনোলজি আয়োজন করেছে অনলাইন ব্যাচ ৬ মাসব্যাপী অ্যাডভান্সড ওয়ার্ডপ্রেস ডেভেলপমেন্ট এবং ফ্রিল্যান্সিং প্রশিক্ষন । ঢাকার বাইরের এবং দেশের বাইরের স্টুডেন্টদের জন্য বাসায় বসেই একদম ব্যাসিক থেকে অ্যাডভান্স লেভেল পর্যন্ত ওয়ার্ডপ্রেস ডেভেলপমেন্ট এবং ফ্রিল্যান্সিং প্রশিক্ষণ এর মাধ্যমে ফ্রিল্যান্সিং এর কাজ এর ব্যবস্থা ।</p>
<div class="page-course-details">
<div class="row">
<div class="col-md-8">
<div class="single-content-leftside">
<h3>অনলাইন ব্যাচ – এর বৈশিষ্ট্য</h3>
<p>১. অনলাইন ব্যাচ এর ক্লাস সংক্রান্ত সকল কার্যক্রম ফেসবুক এ গ্রুপ এর মাধ্যমে পরিচালনা করা হয় এবং ভিডিও টিউটোরিয়াল এর মাধ্যমে ক্লাস পরিচালিত হয় যাতে যেকোন সময় ক্লাসটি দেখা যায়। যার ফলে কোর্স সদস্যবৃন্দ ঘরে বসে কম্পিউটার এর মাধ্যমে ক্লাস করার সুযোগ পাবেন।<br />
২. বিস্তারিত, প্রাঞ্জল এবং বোধগম্য ভিডিও টিউটোরিয়াল এর ব্যবস্থা এবং কোন প্রশ্ন তৈরী হলে বা সাহায্যের দরকার হলে সার্বক্ষিনিক সাপোর্ট সিস্টেম<br />
৩. এই প্রশিক্ষণের সাথে রয়েছে এক মাসের ইন্টার্নি প্রজেক্ট। যা আপনাকে রিয়েল লাইফ এ প্রফেশনাল হিসেবে তৈরি করবে ।<br />
৪. কোর্স চলাকালীন ৫ মাস + ১ মাস ইন্টার্নি সহ পুরো ৬ মাস ব্যাপী সকল ক্লাসের সংরক্ষণ রাখা হয়। কোর্স সদস্যরা যে কোন সময় তাদের সুবিধা অনুসারে ক্লাস করতে পারবেন।<br />
৫. স্টুডেন্ট চাইলে প্রতিদিনই একটি করে ক্লাস এর ডাউনলোড লিঙ্ক নিতে পারবে যদি প্রতিদিন একটি করে ক্লাস ভালোভাবে শেষ করতে পারে<br />
৬. কোন বিষয় সম্পর্কে জানতে অথবা বুঝতে সমস্যা হলে থাকছে ফেসবুক, ও ফোন এবং গ্রুপের মাধ্যমে প্রশ্ন করার সুবিধা।<br />
৭. অনলাইনে বিশ্বের যে কোন প্রান্ত থেকে এখানে যোগ দেওয়া যাবে পছন্দসই সময়ে।<br />
৮. এছাড়া লাইফটাইম সাপোর্ট সুবিধা পাবেন প্রত্যেক শিক্ষার্থী।<br />
৯. ১ মাসের রিয়েল লাইফ প্রোজেক্ট ( ইন্টার্নি ) ।<br />
১০. ফেইসবুক, ফোন এবং গ্রুপ ব্যবহারের মাধ্যমে অনলাইন সাপোর্ট।</p>
</div>
</div>
<div class="col-md-4">
<div class="single-content-righttside">
<h3>অনলাইন ব্যাচ এ ভর্তির যোগ্যতা</h3>
<p>১। আপনার ১টি কম্পিউটার অথবা ল্যাপটপ থাকতে হবে।<br />
২। ১টি সক্রিয় ইন্টারনেট সংযোগ থাকতে হবে , যার নুন্যতম ৫১২ কে.বি.পি.এস সংযোগ স্পিড থাকা লাগবে।<br />
৩। ইংরেজি পড়তে , বুজতে , ও লিখার উপর ব্যাসিক জ্ঞ্যান থাকতে হবে।<br />
৪। প্রতিদিন নুন্যতম ৪ ঘন্টা প্র্যাকটিস করার সময় থাকতে হবে।<br />
৫। যারা কম্পিউটার ব্যাবহার করতে পারেন না এবং কাজ ভালোভাবে না শিখেই লাখ টাকা ইনকাম করার স্বপ্ন দেখছেন কোর্সটি তাদের জন্য নয় । যারা আসলেই ভালোভাবে নিজেকে কাজ শেখার মাধ্যমে দক্ষ করে তুলে পুরোপুরি কাজ শেখা শেষ করে তারপর ফ্রিল্যান্সিং এ আসার মন মানসিকতা আছে, কোর্সটি শুধুমাত্র তাদের জন্য ।<br />
৬। আপনি চাইলে যেকোন সময় বিকাশ, রকেট অথবা ব্যাঙ্ক এর মাধ্যমে পেমেন্ট করে বাসায় বসেই কোর্সটিতে ভর্তি হয়ে ক্লাস শুরু করে দিতে পারবেন । কল করুন পেমেন্ট করার জন্য <span class="text-danger">০১৩১৯-৫১১০১০</span></p>
</div>
</div>
</div>
</div>
<h4>ওয়ার্ডপ্রেস অনলাইন কোর্স এ রয়েছে</h4>
<table class="table table-bordered table-responsive">
<tbody>
<tr>
<td>এইচটিএমএল</td>
<td>সিএসএস</td>
<td>এইচটিএমএল ৫</td>
<td>সিএসএস ৩</td>
<td>জাভাস্ক্রিপ্ট</td>
<td>জেকোয়ারি</td>
</tr>
<tr>
<td>জেকোয়ারী প্লাগিন্স এর ব্যাবহার</td>
<td>ইউ আই কিট এর ব্যবহার</td>
<td>বুটস্ট্র্যাপ এর ব্যবহার</td>
<td>পিএসডি টু এইচটিএমএল ৫</td>
<td>প্রফেশনাল পিএইচপি এবং মাইএসকিউএল</td>
<td>অ্যাজাক্স</td>
</tr>
<tr>
<td>ওয়ার্ডপ্রেস থিম কাস্টমাইজেশন</td>
<td>ওয়ার্ডপ্রেস থিম ডেভেলপমেন্ট</td>
<td>উকমার্স থিম ডেভেলপমেন্ট</td>
<td>ওয়ার্ডপ্রেস প্লাগিন ডেভেলপমেন্ট</td>
<td>মার্কেটপ্লেস এ প্রোফাইল কমপ্লিট করা</td>
<td>প্রজেক্ট ভিত্তিক ইন্টারনি করার সুযোগ এবং বিডিং টেকনিক</td>
</tr>
</tbody>
</table>
<p>এই কোর্সে ওয়েব ডিজাইন এর একদম ব্যাসিক থেকে শুরু করে রেস্পন্সিভ ওয়েব ডিজাইন, পিএইচপি, মাইএসকিউএল এবং ওয়ার্ডপ্রেস এর ব্যাসিক থেকে অ্যাডভান্স লেভেল পর্যন্ত হাতে কলমে প্রশিক্ষন দেয়া হবে যাতে প্রশিক্ষনটি শেষ করার পর সব স্টুডেন্ট প্রফেশনালি চাকরী ক্ষেত্রে অথবা ফ্রিল্যান্সিং মার্কেটপ্লেসে সফলতার সাথে কাজ করে ক্যারিয়ার নিশ্চিত করতে পারে</p>
<table class="table table-bordered table-responsive" style="height: auto;" width="979">
<tbody>
<tr>
<td><b> ক্লাস &#8211; ০১ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> ওয়েব সম্পর্কিত স্বচ্ছ ধারণা</li>
<li><i class="fa fa-check-square"></i> ওয়ার্ডপ্রেস পরিচিতি</li>
<li><i class="fa fa-check-square"></i> ফ্রিল্যান্সিং সম্পর্কিত আলোচনা</li>
<li><i class="fa fa-check-square"></i> এইচ টি এম এল পরিচিতি</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ০২</b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> এইচ টি এম এল এর সঠিক ব্যবহার</li>
<li><i class="fa fa-check-square"></i> বিভিন্ন ট্যাগ এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> বিভিন্ন অ্যাট্রিবিউট এর ব্যবহার</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ০৩</b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> এইচ টি এম এল ট্যাগ এর লিস্ট প্রদান</li>
<li><i class="fa fa-check-square"></i> প্রয়োজনীয় সকল ট্যাগ এর ব্যবহার</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ০৪ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> প্রয়োজনীয় সকল অ্যাট্রিবিউট এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> এইচ টি এম এল সম্পর্কিত সমস্যার সমাধান</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ০৫</b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> সি এস এস পরিচিতি</li>
<li><i class="fa fa-check-square"></i> ইনলাইন, ইন্টারনাল এবং এক্সটারনাল সি এস এস এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> সি এস এস প্রপার্টি পরিচিতি</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ০৬</b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> কালার, ব্যাকগ্রাউন্ড কালার, হাইট, উইধ</li>
<li><i class="fa fa-check-square"></i> মারজিন, প্যাডিং</li>
<li><i class="fa fa-check-square"></i> ফ্লোট, ওভারফ্লো</li>
<li><i class="fa fa-check-square"></i> বর্ডার, বর্ডার র‍্যাডিয়াস</li>
</ul>
</td>
</tr>
<tr>
<td><b> ক্লাস &#8211; ০৭</b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> ডিস্প্লে এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> থিম ফরেস্ট এর ডিজাইন সম্পর্কে ধারণা</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ০৮</b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> ফেইসবুক এর মত করে একটা ওয়েবসাইট ডিজাইন</li>
<li><i class="fa fa-check-square"></i> ব্যাসিক ডিজাইন স্ট্রাকচার তৈরী</li>
<li><i class="fa fa-check-square"></i> অন্যান্য প্রপার্টির ব্যবহার</li>
<li><i class="fa fa-check-square"></i> সি এস এস এর গুরুত্বপূর্ণ সব প্রপার্টির ব্যবহার</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ০৯ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> ফেইসবুক এর মত একটা ডিজাইন</li>
<li><i class="fa fa-check-square"></i> সিএসএস ৩ এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> সিএসএস ৩ এর প্রপার্টি সম্পর্কে ধারণা</li>
<li><i class="fa fa-check-square"></i> মিডিয়া কোয়ারী এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> সিএসএস ৩ এর প্রপার্টি প্রিফিক্স</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ১০ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> রেস্পন্সিভ পরিচিতি</li>
<li><i class="fa fa-check-square"> </i> পূর্ণাঙ্গ ডিজাইনকে রেস্পন্সিভ করার পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> পূর্ববর্তী ডিজাইনকে রেস্পন্সিভ করার পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> মিডিয়া কোয়ারী এর সকল ব্যবহার</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ১১ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> ফেইসবুক এর মত ডিজাইনটি কমপ্লিট করা</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ১২ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> মেনু তৈরী করার পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> সাবমেনু তৈরী করার পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> মেনু রেস্পন্সিভ করার পদ্ধতি</li>
</ul>
</td>
</tr>
<tr>
<td><b> ক্লাস &#8211; ১৩ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> ফটোশপ পরিচিতি</li>
<li><i class="fa fa-check-square"></i> ফটোশপ টুলস</li>
<li><i class="fa fa-check-square"></i> পিএসডি সম্পর্কিত ধারণা</li>
<li><i class="fa fa-check-square"></i> পিএসডি থেকে ইমেজ আলাদা করার প্রক্রিয়া</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ১৪ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> পিএসডি থেকে এইচটিএমএল পরিচিতি</li>
<li><i class="fa fa-check-square"></i> বিফোর এবং আফটার এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> ট্রাইএঙ্গেল এর ব্যবহার</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ১৫ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> পিএসডি থেকে এইচটিএমএল করার পদ্ধতি ( পর্ব ২ )</li>
<li><i class="fa fa-check-square"></i> ফ্রি পিএসডি ওয়েব টেমপ্লেট খুঁজে বের করার পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> পিএসডি টু এইচটিএমএল এর পদ্ধতি</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ১৬ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> সিএসএস ফ্রেমওয়ার্ক এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> বুটস্ট্র্যাপ দিয়ে বিভিন্ন সেকশন ডিজাইন</li>
<li><i class="fa fa-check-square"></i> বুটস্ট্র্যাপ এর বিভিন্ন ইফেক্ট এর ব্যবহার</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ১৭</b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> বুটস্ট্রাপ এবং আইকন এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> অন্যান্য ফ্রেমওয়ার্ক সম্পর্কিত ধারণা</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ১৮ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> বুটস্ট্র্যাপ এর বিভিন্ন কম্পোনেন্ট সম্পর্কিত ধারণা</li>
<li><i class="fa fa-check-square"></i> বুটস্ট্র্যাপ এর বিভিন্ন ক্লাস সম্পর্কে ধারণা</li>
</ul>
</td>
</tr>
<tr>
<td><b> ক্লাস &#8211; ১৯ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> বুটস্ট্র্যাপ এর মাধ্যমে পিএসডি টু এইচটিএমএল করার পদ্ধতি</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ২০ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> বুটস্ট্র্যাপ দিয়ে পিএসডি টু এইচটিএমএল ( পর্ব ১ )</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ২১ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> বুটস্ট্র্যাপ দিয়ে পিএসডি টু এইচটিএমএল ( পর্ব ২ )</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ২২ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> বুটস্ট্র্যাপ দিয়ে পিএসডি টু এইচটিএমএল ( পর্ব ৩ )</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ২৩ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> অন্য একটি ডিজাইন পুর্ণাংগভাবে তৈরী করা</li>
<li><i class="fa fa-check-square"></i> ইউ আই কিট এর ব্যবহার</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ২৪</b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> ইউ আই কিট এর ব্যবহার ( পার্ট ২ )</li>
<li><i class="fa fa-check-square"></i> জাভাস্ক্রিপ্ট পরিচিতি</li>
<li><i class="fa fa-check-square"></i> জাভাস্ক্রিপ্ট এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> জাভাস্ক্রিপ্ট  ব্যাসিক</li>
</ul>
</td>
</tr>
<tr>
<td><b> ক্লাস &#8211; ২৫</b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> জাভাস্ক্রিপ্ট ফাংশন</li>
<li><i class="fa fa-check-square"></i> জাভাস্ক্রিপ্ট কন্ডিশন</li>
<li><i class="fa fa-check-square"></i> জাভাস্ক্রিপ্ট এর প্র্যাক্টিকাল প্রজেক্ট</li>
<li><i class="fa fa-check-square"></i> জেকোয়ারী পরিচিতি</li>
<li><i class="fa fa-check-square"></i> জেকোয়ারী ডকুমেন্টেশন</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ২৬ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> জেকোয়ারী এর বিভিন্ন ব্যবহার</li>
<li><i class="fa fa-check-square"></i> জেকোয়ারী এর বিভিন্ন মেথড</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ২৭ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i>মেনুতে জেকোয়ারী এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> ফর্ম এ জেকোয়ারী এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> জেকোয়ারী এর মাধ্যমে স্ক্রল টু টপ তৈরী করা</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ২৮ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> জেকোয়ারী ইউ আই পরিচিতি</li>
<li><i class="fa fa-check-square"></i> জেকোয়ারী ইউ আই এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> জেকোয়ারী ইউ আই এর বিভিন্ন মেথড এর ব্যবহার</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ২৯</b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> জেকোয়ারী ইউ আই এর সকল মেথড</li>
<li><i class="fa fa-check-square"></i> মুটুলস সহ অন্যান্য লাইব্রেরী শেখার পদ্ধতি</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ৩০ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> জেকোয়ারী প্লাগিন পরিচিতি</li>
<li><i class="fa fa-check-square"></i> লাইটবক্স এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> মিক্স ইট আপ এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> আউল ক্যারোসেল এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> জেকোয়ারী এর অন্যান্য প্লাগিন এর ব্যবহার</li>
</ul>
</td>
</tr>
<tr>
<td><b> ক্লাস &#8211; ৩১ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> জেকোয়ারী প্যারালাক্স এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> স্টেলার এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> ওয়াও জে এস এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> এনিমেট জে এস এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> জেকোয়ারী প্লাগিন ডেভেলপমেন্ট সম্পর্কে ধারণা</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ৩২ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> লোকাল সার্ভার পরিচিতি</li>
<li><i class="fa fa-check-square"></i> XAMPP এবং Wamp সমস্যার সমাধান</li>
<li><i class="fa fa-check-square"></i> ওয়ার্ডপ্রেস ব্যাসিক ধারণা</li>
<li><i class="fa fa-check-square"></i> ওয়ার্ডপ্রেস থিম সম্পর্কিত ধারণা</li>
<li><i class="fa fa-check-square"></i> ওয়ার্ডপ্রেস প্লাগিন সম্পর্কিত ধারণা</li>
<li><i class="fa fa-check-square"></i> ওয়ার্ডপ্রেস ড্যাশবোর্ড সম্পর্কিত ধারণা</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৩৩ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> সি প্যানেল পরিচিতি</li>
<li><i class="fa fa-check-square"></i> সি প্যানেল এর মাধ্যমে ওয়ার্ডপ্রেস ইন্সটলেশন</li>
<li><i class="fa fa-check-square"></i> ওয়ার্ডপ্রেস ড্যাশবোর্ড পরিচিতি</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৩৪ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> প্রিমিয়াম থিম কাস্টমাইজেশন</li>
<li><i class="fa fa-check-square"></i> মেগানিউজ থিম এর সাথে পরিচয়</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৩৫ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> প্রিমিয়াম থিম কাস্টমাইজেশন</li>
<li><i class="fa fa-check-square"></i> ওয়ার্ডপ্রেস প্লাগিন কাস্টমাইজেশন</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৩৬ </b></p>
<ul class="course-item-page">
<li>ওয়ার্ডপ্রেস ফ্রি থিম কাস্টমাইজেশন</li>
<li><i class="fa fa-check-square"></i> Fiverr সম্পর্কিত ধারণা</li>
<li><i class="fa fa-check-square"></i> Fiverr এ গিগ তৈরী</li>
<li><i class="fa fa-check-square"></i> কাজ পাওয়ার পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> ওয়ার্ডপ্রেস সাইট ট্রান্সফার করার পদ্ধতি</li>
</ul>
</td>
</tr>
<tr>
<td><b> ক্লাস &#8211; ৩৭ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> মিডিয়াসেন্টার থিম নিয়ে আলোচনা</li>
<li><i class="fa fa-check-square"></i> প্রিমিয়াম থিম কাস্টমাইজ করার সহজ পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> ঊকমার্স এবং ইকমার্স নিয়ে আলোচনা</li>
<li><i class="fa fa-check-square"></i> ঊকমার্স প্লাগিন এর ব্যবহার</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ৩৮ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> নিউজপেপার থিম পরিচিতি</li>
<li><i class="fa fa-check-square"></i> নিউজপেপার থিম সম্পর্কিত আলোচনা</li>
<li><i class="fa fa-check-square"></i> নিউজপেপার থিম এর ব্যবহার</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৩৯ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> কন্টাক্ট ফর্ম এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> ল্যান্ডিং পেজ তৈরী</li>
<li><i class="fa fa-check-square"></i> স্কুইজ পেজ তৈরী</li>
<li><i class="fa fa-check-square"></i> রেভল্যুশন স্লাইডার</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৪০ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> শপিফাই পরিচিতি</li>
<li><i class="fa fa-check-square"></i> আপওয়ার্ক সম্পর্কে ধারণা</li>
<li><i class="fa fa-check-square"></i> আপওয়ার্ক প্রফাইল অ্যাপ্রুভ করানোর বৈধ পদ্ধতি</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৪১ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> আপওয়ার্কের কাজে অ্যাপ্লাই করার পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> আপওয়ার্কে কাজ পাওয়ার সহজ উপায়</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৪২ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> আপওয়ার্কের বিস্তারিত আলোচনা</li>
<li><i class="fa fa-check-square"></i> Freelancer.com পরিচিতি</li>
</ul>
</td>
</tr>
<tr>
<td><b> ক্লাস &#8211; ৪৩ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> পিএইচপি পরিচিতি</li>
<li><i class="fa fa-check-square"></i> প্রিন্ট, ভ্যারিয়েবল, ডাটা টাইপ</li>
<li><i class="fa fa-check-square"></i> কনক্যাট, ফাংশন, কন্ডিশন</li>
<li><i class="fa fa-check-square"></i> অ্যারে, প্যারামিটার, লুপ</li>
<li><i class="fa fa-check-square"></i> প্রিন্ট আর, ভার ডাম্প</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ৪৪ </b></p>
<ul class="course-item-page">
<li></li>
<li>XAMPP এবং Wamp সমস্যার সমাধান</li>
<li><i class="fa fa-check-square"></i> কন্সট্যান্ট</li>
<li><i class="fa fa-check-square"></i> গেট, পোস্ট এবং রিকোয়েস্ট মেথড</li>
<li><i class="fa fa-check-square"></i> সেশন, সার্ভার ভ্যারিয়েবল</li>
<li><i class="fa fa-check-square"></i> গ্লোবাল ভ্যারিয়েবল</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৪৫ </b></p>
<ul class="course-item-page">
<li>ওয়ার্ডপ্রেস ফ্রি থিম কাস্টমাইজেশন</li>
<li><i class="fa fa-check-square"></i> রিকয়ার, ইনক্লুড</li>
<li><i class="fa fa-check-square"></i> কুকি, ফিল্টার ভ্যারিয়েবল</li>
<li><i class="fa fa-check-square"></i> ইরর এর ধরণ</li>
<li><i class="fa fa-check-square"></i> এক্সেপশন</li>
<li><i class="fa fa-check-square"></i> মেইল ফাংশন এবং ফাইল সিস্টেম</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৪৬ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> স্ট্রিং ফাংশন</li>
<li><i class="fa fa-check-square"></i> অ্যারে ফাংশন</li>
<li><i class="fa fa-check-square"></i> সুইচ কেস, </li>
<li><i class="fa fa-check-square"></i> প্রয়োজনীয় পিএইচপি ফাংশন</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৪৭ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> অ্যাজাক্স পরিচিতি</li>
<li><i class="fa fa-check-square"></i> অ্যাজাক্স এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> মাই এস কিউ এল পরিচিতি</li>
<li><i class="fa fa-check-square"></i> বিভিন্ন মাই এস কিউ এল কোয়ারী</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৪৮ </b></p>
<ul class="course-item-page">
<li>ওয়ার্ডপ্রেস ফ্রি থিম কাস্টমাইজেশন</li>
<li><i class="fa fa-check-square"></i> মাই এস কিউ এল এর প্রয়োজনীয় কোয়ারী</li>
<li><i class="fa fa-check-square"></i> CRUD অপারেশন</li>
<li><i class="fa fa-check-square"></i> পিএইচ পি এবং মাইএসকিউএল দিয়ে প্র্যাক্টিকাল প্রজেক্ট</li>
</ul>
</td>
</tr>
<tr>
<td><b> ক্লাস &#8211; ৪৯ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> পিএইচপি, মাইএসকিউএল, জেকোয়ারী এবং অ্যাজাক্স ব্যবহার করে একটি চ্যাটিং অ্যাপ্লিকেশন তৈরী</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ৫০ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> ওয়ার্ডপ্রেস কোডেক্স সম্পর্কে ধারণা</li>
<li><i class="fa fa-check-square"></i> ওয়ার্ডপ্রেস থিম ডেভেলপমেন্ট পরিচিতি</li>
<li><i class="fa fa-check-square"></i> functions.php সম্পর্কিত আলোচনা</li>
<li><i class="fa fa-check-square"></i> থিম এর হেডার ইমেজ, ব্যাকগ্রাউন্ড, লুপ</li>
<li><i class="fa fa-check-square"></i> ব্যাসিক থিম তৈরী</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৫১ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> অ্যাকশন হুক এবং ফিল্টার হুক এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> কাস্টম ফিল্ড, কাস্টম মেটাবক্স</li>
<li><i class="fa fa-check-square"></i> কাস্টম পোস্ট টাইপ</li>
<li><i class="fa fa-check-square"></i> কাস্টম লুপ</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৫২ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> পেজ টেমপ্লেট, ডিফল্ট টেমপ্লেট</li>
<li><i class="fa fa-check-square"></i> সাইডবার রেজিস্ট্রেশন</li>
<li><i class="fa fa-check-square"></i> শর্টকোড রেজিস্টার, নেস্টেড শর্টকোড</li>
<li><i class="fa fa-check-square"></i> পেইজ বিল্ডার এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> থিম অপশন</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৫৩ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> ওয়ান পেজ থিম ডেভেলপমেন্ট</li>
<li><i class="fa fa-check-square"></i> চাইল্ড থিম ডেভেলপমেন্ট</li>
<li><i class="fa fa-check-square"></i> কমপ্লিকেটেড থিম ডেভেলপমেন্ট</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৫৪ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> প্রিমিয়াম কোয়ালিটির থিম তৈরী</li>
<li><i class="fa fa-check-square"></i> থিমফরেস্ট এর এইচটিএমএল টেমপ্লেট থেকে ওয়ার্ডপ্রেস থিম কনভার্শন</li>
<li><i class="fa fa-check-square"></i> থিম এর স্ট্যান্ডার্ড মেইন্টেইন করা</li>
</ul>
</td>
</tr>
<tr>
<td><b> ক্লাস &#8211; ৫৫ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> কমেট এইচটিএমএল টেমপ্লেট থেকে থিমে কনভার্শন</li>
<li><i class="fa fa-check-square"></i> স্ট্যান্ডার্ড থিম ডেভেলপমেন্ট</li>
<li><i class="fa fa-check-square"></i> বিভিন্ন পেইজ ডায়নামিক করা</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ৫৬ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> থিম এর মেনু ডায়নামিক করার পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> মেগামেনু তৈরী করার পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> মেগামেনু ডায়নামিক করার পদ্ধতি</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৫৭ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> প্লাগিন ব্যতিত মেগামেনু ডায়নামিক করার পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> প্রিমিয়াম থিমে কাস্টম পোস্ট টাইপ রেজিস্ট্রেশন</li>
<li><i class="fa fa-check-square"></i> প্রিমিয়াম থিমে শর্টকোড রেজিস্ট্রেশন</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৫৮ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> ফিল্টার সিস্টেম ডায়নামিক করা</li>
<li><i class="fa fa-check-square"></i> মিক্স ইট আপ, আইসোটোপ প্লাগিন ডায়নামিক করা</li>
<li><i class="fa fa-check-square"></i> জেকোয়ারী প্লাগিনকে ওয়ার্ডপ্রেস থিমে ইন্টিগ্রেট করা</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৫৯ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> ভিজুয়াল কম্পোজার ইন্টিগ্রেশন</li>
<li><i class="fa fa-check-square"></i> কমেন্ট সেকশন ডায়নামিক করার পদ্ধতি</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৬০ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> যেকোন ধরনের পেজিনেশন তৈরীর পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> উকমার্স থিম ডেভেলপমেন্ট পরিচিতি</li>
<li><i class="fa fa-check-square"></i> উকমার্স থিম ডেভেলপমেন্ট এর সঠিক পদ্ধতি</li>
</ul>
</td>
</tr>
<tr>
<td><b> ক্লাস &#8211; ৬১ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> উকমার্স থিমে ডিফল্ট টেমপ্লেট ওভাররাইড করা</li>
<li><i class="fa fa-check-square"></i> উকমার্স থিমে টেমপ্লেট আপডেট করা</li>
<li><i class="fa fa-check-square"></i> শপ পেজ ডায়নামিক করা</li>
<li><i class="fa fa-check-square"></i> উকমার্স থিমের হুক এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> উকমার্স থিম ডেভেলপমেন্ট ডকুমেন্টেশন</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ৬২ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> উবারমেনু এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> উকমার্স মেম্বারশিপ এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> উকমার্স এর মাধ্যমে এইচটিএমএল টেমপ্লেট ডায়নামিক করা</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৬৩ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> মিনিকার্ট ডায়নামিক করার পদ্ধতি</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৬৪ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> প্রিমিয়াম থিমে উকমার্স এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> WPDB এর ব্যবহার</li>
<li><i class="fa fa-check-square"></i> WPDB এর সকল ফাংশন</li>
<li><i class="fa fa-check-square"></i> WPDB এর মাধ্যমে CRUD অপারেশন</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৬৫ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> প্লাগিন ডেভেলপমেন্ট পরিচিতি</li>
<li><i class="fa fa-check-square"></i> প্লাগিন ডেভেলপমেন্ট এর মাধ্যমে ওয়েবসাইট এর ফাংশনালিটি বৃদ্ধি করা</li>
<li><i class="fa fa-check-square"></i> প্রথম প্লাগিন তৈরী</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৬৬ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> ডাক্তারদের তথ্য ভিত্তিক প্লাগিন বানানো</li>
<li><i class="fa fa-check-square"></i> স্লাইডার প্লাগিন বানানো</li>
</ul>
</td>
</tr>
<tr>
<td><b> ক্লাস &#8211; ৬৭ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"> </i> কর্মচারীর তালিকা ভিত্তিক প্লাগিন তৈরী</li>
<li><i class="fa fa-check-square"></i> পূর্নাঙ্গ প্লাগিন তৈরীর পদ্ধতি</li>
</ul>
</td>
<td><b> ক্লাস &#8211; ৬৮ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> সার্চ ফিল্ড ডায়নামিক করার পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> সার্চ পেইজ ডায়নামিক করার পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> অ্যাডভান্স লেভেল এর সার্চ অপশন ডায়নামিক করা</li>
<li><i class="fa fa-check-square"></i> অনেকগুলো ফিল্ড ভিত্তিক সার্চ অপশন ডায়নামিক করা</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৬৯ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> এমপ্লয়ী লিস্ট প্লাগিন পূর্নাঙ্গ ভাবে শেষ করা</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৭০ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> কিছু মটিভেশনাল কথা</li>
<li><i class="fa fa-check-square"></i> মার্কেটপ্লেসে ক্যারিয়ার বিষয়ক গাইডলাইন</li>
</ul>
</td>
<td><b>ক্লাস &#8211; ৭১ </b></p>
<ul class="course-item-page">
<li><i class="fa fa-check-square"></i> WordPress.org তে নিজের প্লাগিন আপলোড করার পদ্ধতি</li>
<li><i class="fa fa-check-square"></i> বিভিন্ন মার্কেটপ্লেস থেকে কাজ পাওয়ার পদ্ধতি</li>
</ul>
</td>
<td></td>
</tr>
</tbody>
</table>
					</div>
					</div>
</div>

<!-- Footer Area -->
    <div class="footer-area-background">
        <div class="widget-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="widget-style">
                            <div class="my-widget-style"><h2>ডেলটা ইনষ্টিটিউট অফ টেকনোলজি</h2>			<div class="textwidget"><p><img src="delta 1.jpg" alt="" width="300" height="87" class="alignnone size-medium wp-image-30" /></p>
<p>ডেলটা ইনষ্টিটিউট অফ টেকনোলজি আইটির একটি অঙ্গ প্রতিষ্ঠান । আমাদের প্রধান উদ্দেশ্য বঙ্গবন্ধু হাই-টেক সিটিতে সর্ববৃহত ফ্রীল্যান্সারস কমিউনিটি তৈরী করা । আমাদের সকল কোর্স ৬ মাস মেয়াদী এবং ৫ মাস কাজ শেখার পর এক মাস প্র্যাক্টিকাল কাজ করার মাধ্যমে স্টুডেন্টদেরকে এক্সপার্ট করে তোলা হয় ।</p>
</div>
		</div>                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="widget-style widget-another">
                            <div class="my-widget-style"><h2>ডেলটা ইনষ্টিটিউট অফ টেকনোলজি লিংকস</h2>			<div class="textwidget"><ul>
<li><a href="https://www.facebook.com/Delta6262" target="_blank" rel="noopener">ফেইসবুক পেইজ</a></li>
<li><a href="https://www.facebook.com/groups/282844492513638" target="_blank" rel="noopener">ফেইসবুক গ্রুপ</a></li>
<li><a href="http://youtube.com/softtechit" target="_blank" rel="noopener"> ইউটিউব চ্যানেল</a></li>
<li><a href="#" target="_blank" rel="noopener"> কোর্সসমূহ </a></li>
<li><a href="http://softtech-it.com/wordpresss-course-in-bangladesh/" target="_blank" rel="noopener"> ওয়ার্ডপ্রেস কোর্স </a></li>
<li><a href="http://softtech-it.com/online-course/" target="_blank" rel="noopener"> অনলাইন কোর্স </a></li>
<li><a href="http://softtech-it.com/seminar/" target="_blank" rel="noopener">ডেলটা ইনষ্টিটিউট অফ টেকনোলজিসেমিনার</a></li>
<li><a href="delta_commonication.php" target="_blank" rel="noopener"> যোগাযোগ </a></li>
</ul>
</div>
		</div>                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="widget-style">
                            <div class="my-widget-style"><h2>যোগাযোগ করুন</h2>			<div class="textwidget"><p><i class="fa fa-map-marker"> </i>বঙ্গবন্ধু হাই-টেক সিটি, কালিয়াকৈর, গাজীপুর।</p>
<p><i class="fa fa-phone-square"> </i> ০১৩১৯-৫১১০০৮, ০১৩১৯-৫১১০০৯</p>
<p><i class="fa fa-envelope-o"> </i> deltainstituteoftechnology@gmail.com</p>
<p><i class="fa fa-globe"></i> www.kaliakoir-delta.com</p>
</div>
		</div>                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-area">
            <div class="container">
                <div class="footer">
                    <p> কপিরাইট &copy; ডেলটা ইনষ্টিটিউট অফ টেকনোলজি - সর্বসত্ত্ব সংরক্ষিত  </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Area -->
    <a href="#" class="scrolltotop"> <i class="fa fa-angle-up"></i> </a>
    <!-- FB Messenger -->
<div id="fbMsg">
	<img data-remodal-target="fb-messenger" src="http://softtech-it.com/wp-content/plugins/fb-messenger/images/fb-messenger.png">
</div>

<div class="remodal" data-remodal-id="fb-messenger">
	<div class="fb-page" data-tabs="messages , events" data-href="http://facebook.com/softtechitinstitute" data-width="310" data-height="330" data-href="http://facebook.com/softtechitinstitute" data-small-header="true"  data-hide-cover="false" data-show-facepile="true" data-adapt-container-width="true">
		<div class="fb-xfbml-parse-ignore">
			<blockquote>Loading...</blockquote>
		</div>
	</div>
	</div>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.6";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<!-- End FB Messenger -->
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/softtech-it.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}}};
/* ]]> */
</script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.0.3'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/plugins/fb-messenger/js/index.js?ver=4.9.15'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-includes/js/wp-embed.min.js?ver=4.9.15'></script>
	

</body>

</html>
<!--Generated by Endurance Page Cache-->