<?php
$conn=mysqli_connect("localhost","root","");
	mysqli_select_db($conn,"ict_solution_and_comper_institute");
?>
<html>
<head>
<meta charset="utf-8">
<title>Perfect Beauty BD</title>
   <script src="js/js1.js"></script>
  <script src="js/js2.js"></script>
  <script>
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true
    });
  } );
  </script>
<style>
*{
	margin: 0px; padding: 0px;
}
.company_title{
	width:700px;
	height:37px;
	background-color:Green;
	margin: 0 auto;
	border-radius: 8px;
	border: 3px solid blue;
}
.perfect1{
	background-color: pink;
    border: 3px solid blue;
    border-radius: 12px;
    height: 830px;
    margin: 10px auto 0;
    padding-top: 20px;
    text-align: center;
    width: 700px;
}
.company_title h1{
	color: white;
	text-align: center;
	font-size:30px;
}
.company_title h2{
	color: white;
	text-align: center;
	font-size:20px;
}
.company_title h3{
	color: white;
	text-align: center;
	font-size:20px;
}
.logo{
	width: 100px;
	height: 0px;
	margin-top: -178px;
    margin-left: 4px;
}
.perfect{
	color: Green;
    text-align: center;
    font-size: 40px;
    font-weight: bold;
}
.contact_number{
	color: black;
	text-align: center;
	font-size:25px;
}
.mirpur{
	color: black;
	text-align: center;
	font-size:25px;
}
.cours{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	font-size: 25px;
	margin-left: -5px;
}
.cours1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 3px;
}
.invoice_No{
	padding-left: 44px;
    padding-top: 190px;
    text-align: left;
	font-size: 25px;
	margin-left: 23px;
	margin-top: -184px;
}
.invoice_No1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 3px;
}
.Session{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	font-size: 25px;
	margin-left: 61px;
}
.Session1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 4px;
}
.Customer_Name{
	padding-left: 10px;
    text-align: left;
	border-radius:10px;
	margin-top: 9px;
	font-size: 25px;
}
.Customer_Name1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 465px;
	height: 35px;
	padding-left: 7px;
	margin-left: 196px;
	margin-top: -30px;
	font-size: 16px;
}
.div1{
	margin-left: 178px;
	margin-top: -29px;
}
.Product_Name{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left:-31px;
	margin-top: 0px;
	font-size: 25px;
}
.Product_Name1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 465px;
	height: 35px;
	padding-left: 7px;
	margin-left: 193px;
	margin-top: -30px;
	font-size: 16px;
}
.div2{
	margin-left: 174px;
	margin-top: -29px;
}
.Address{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left:-31px;
	margin-top: 0px;
	font-size: 25px;
}
.Address1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 465px;
	height: 35px;
	padding-left: 7px;
	margin-left: 193px;
	margin-top: -30px;
	font-size: 16px;
}
.div4{
	margin-left: 174px;
	margin-top: -29px;
}
.mobile_number{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left:-31px;
	margin-top: 0px;
	font-size: 25px;
}
.m_number{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 465px;
	height: 35px;
	padding-left: 7px;
	margin-left: 193px;
	margin-top: -30px;
	font-size: 16px;
}
.div5{
	margin-left: 174px;
	margin-top: -29px;
}
.unit_price{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-top: 0px;
	font-size: 25px;
	margin-left: -31px;
}
.unit_price1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 465px;
	height: 35px;
	padding-left: 7px;
	margin-left: 193px;
	margin-top: -30px;
	font-size: 16px;
}
.div3{
	margin-left: 175px;
	margin-top: -29px;
}
.quentity{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left:-31px;
	margin-top: 0px;
	font-size: 25px;
}
.quentity1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 465px;
	height: 35px;
	padding-left: 7px;
	margin-left: 193px;
	margin-top: -30px;
	font-size: 16px;
}
.div6{
	margin-left: 175px;
	margin-top: -29px;
}
.grose{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	font-size: 25px;
	margin-left: -32px;
}
.grose1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 192px;
    margin-top: -28px;
}
.div7{
	margin-left: 175px;
	margin-top: -29px;
}
.discount{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	font-size: 25px;
	margin-left: -32px;
}
.discount1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 192px;
    margin-top: -28px;
}
.div8{
	margin-left: 175px;
	margin-top: -29px;
}
.net_price{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	font-size: 25px;
	margin-left: -32px;
}
.net_price1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 192px;
    margin-top: -28px;
}
.div9{
	margin-left: 175px;
	margin-top: -29px;
}
.payment{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	font-size: 25px;
	margin-left: -32px;
}
.payment1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 192px;
    margin-top: -28px;
}
.div10{
	margin-left: 175px;
	margin-top: -29px;
}
.due{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	font-size: 25px;
	margin-left: -32px;
}
.due1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 192px;
    margin-top: -28px;
}
.div11{
	margin-left: 175px;
	margin-top: -29px;
}
.date{
	text-align: left;
	font-size: 25px;
	margin-top: 35px;
	font-size: 25px;
	margin-left: 133px;
}
.datepicker{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 138px;
	height: 35px;
	padding-left: 7px;
	margin-top: 148px;
}
.btn {
    padding-top: 1px;
    background-color: Red;
    margin-top: 20px;
    padding-bottom: 13px;
	height: 55px;
}

.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: black;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  cursor: pointer;
}

.button {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
  margin-right: 4px;
}

</style>
<body>
<section class="company_title">
<marquee>
<h1>Perfect Beauty BD</h1>
</marquee>
</section>


<section class="perfect1">
<form action="perfect_beauty_bd.php" Method="POST" cnctype="multipart/form-data" class="form_area">
	<div class="perfect">
	<h1><center>Perfect Beauty BD</center></h1>
	</div>
	<div class="contact_number">
	<h3><center>Contact Number :01973-633163</center></h3>
	</div>
	<div class="mirpur">
	<h4><center>Mirpur, Dhaka-1207</center></h4><br>
	</div>
	<div class="logo">
	<img src="perfect.png" width="100px" height="100px" alt="ayub">
	</div>
	<div class="invoice_No">
	<b>Invoice ID :</b> <input class="invoice_No1" type="text" name="Invoice_No" placeholder="Invoice No">
	</div>
	<div class="Customer_Name">
	<b>Customer Name<div class="div1">:</div></b> <input class="Customer_Name1" type="text" name="Customer_Name" placeholder="Customer Name">
	</div>
	<div class="Product_Name">
	<b>Product Name<div class="div2">:</div></b> <input class="Product_Name1" type="text" name="Product_Name" placeholder="Product Name">
	</div>
	<div class="Address">
	<b>Address <div class="div4">:</div></b><input class="Address1" type="text" name="Address" placeholder="Address">
	</div>
	<div class="mobile_number">
	<b>Mobil Number<div class="div5">:</div></b> <input class="m_number" type="text" name="Mobil_Number" placeholder="Mobil Number">
	</div>	
	<div class="unit_price">
	<b>Unit Price <div class="div3">:</div></b> <input class="unit_price1" type="text" name="Unit_Price" placeholder="Unit Price">
	</div>	
	<div class="quentity">
	<b>Quentity<div class="div6">:</div></b> <input class="quentity1" type="text" name="Quentity" placeholder="Quentity">
	</div>
	<div class="grose">
	<b>Grose Price <div class="div7">:</div></b> <input class="grose1" type="text" name="Grose_Price" placeholder="Grose Price">
	</div>
	<div class="discount">
	<b>Discount <div class="div8">:</div></b> <input class="discount1" type="text" name="Discount" placeholder="Discount">
	</div>
	<div class="net_price">
	<b>Net Price <div class="div9">:</div></b> <input class="net_price1" type="text" name="Net_Price" placeholder="Net Price">
	</div>
	<div class="payment">
	<b>Payment <div class="div10">:</div></b> <input class="payment1" type="text" name="Payment" placeholder="প্রদান">
	</div>
	<div class="due">
	<b>Due <div class="div11">:</div></b> <input class="due1" type="text" name="Due" placeholder="বকেয়া">
	</div>
	<div class="date">
	<b>Date :</b> <input class="datepicker" type="date" name="Date" placeholder="তারিখ">
	</div>
	<div class="btn">
	<input type="submit" class="button" name="submit" value="Save">
	
	</div>
	</section>
</body>
</head>

</html>
<?php
if(isset($_POST["submit"]))
{
	mysqli_query($conn,"insert into perfect_beauty value ('$_POST[Date]')");
}
?>