<?php
$conn = mysqli_connect('localhost','root','','perfect_beauty_bd');
if ($conn) {
	if(isset($_POST['Search'])){
		$Invoice_No=$_POST['Invoice_No'];
		
		
				
		$sql= "select * from  perfect_beauty where Invoice_No='$Invoice_No'";
		$result = mysqli_query($conn, $sql);
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf8">
<title>ভর্তি ফরম</title>
  <div class="date_picker">
 <script>
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true,
	  dateFormat:"yy-mm-dd"
	  });
  } );
  </script>
  </div>
  <script>
  function printRoutine(){
		printDiv("print_area");
	}
	
	function printDiv(Print) {
     var printContents = document.getElementById(Print).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

    window.print();
	
	  
	document.body.innerHTML = originalContents;
	
	 
}
  </script>
<style>

*{
	margin:0px; padding:0px;
}
.main{
	width:528px; height:816px;	background-color: white;margin: 0 auto;	border-radius: 8px;	border:10px solid blue;	margin-top: 10px;
}
.delta{
	font-size: 35px;
    font-weight: bold;
    color: green;
}
.bangabandhu{
	font-size: 30px;
}
.kaliakoir{
	font-size: 25px;
}
.image{
	margin-top: -10px;
    margin-left: 205px;
	height: 700px;
    width: 700px;
}
.admission{
	font-size: 30px;
    font-weight: bold;
    color: red;
    border: 2px solid;
    width: 230px;
    margin-left: 285px;
}
.invoice_No{
	margin-top: -540px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon1{
	margin-top: -18px;
    margin-left: 105px;
    font-weight: bold;
}
.invoice_No1{
	margin-top: -25px;
    margin-left: 120px;
    font-size: 16px;
    font-weight: bold;
}
.Customer_Name{
	margin-top: -11px;
    margin-left: 240px;
    font-size: 16px;
}
.semicolon2{
	margin-top: -18px;
    margin-left: 105px;
    font-weight: bold;
}
.Customer_Name1{
	margin-top: -25px;
    margin-left: 355px;
    font-size: 16px;
    font-weight: bold;
}
.Product_Name{
	margin-top: 30px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon3{
	margin-top: -18px;
    margin-left: 110px;
    font-weight: bold;
}
.Product_Name1{
	margin-top: -25px;
    margin-left: 120px;
    font-size: 16px;
    font-weight: bold;
}
.delivery{
	margin-top: -33px;
    margin-left: 330px;
    font-size: 16px;
}
.semicolon4{
	margin-top: -18px;
    margin-left: 105px;
    font-weight: bold;
}
.delivery1{
	margin-top: -25px;
    margin-left: 120px;
    font-size: 16px;
    font-weight: bold;
}
.Address{
	 margin-top: 10px;
    font-size: 16px;
    margin-left: 5px;
}
.semicolon5{
	margin-top: -18px;
    margin-left: 105px;
    font-weight: bold;
}
.Address1{
	margin-top: -25px;
    margin-left: 120px;
    font-size: 16px;
    font-weight: bold;
}
.mobile_number{
	margin-top: 25px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon6{
	margin-top: -18px;
    margin-left: 75px;
    font-weight: bold;
}
.m_number{
	margin-top: -25px;
    margin-left: 120px;
    font-weight: bold;
}
.unit_price {
	margin-top: -16px;
    margin-left: 290px;
    font-size: 16px;
}
.semicolon7{
	margin-top: -18px;
    margin-left: 110px;
    font-weight: bold;
}
.unit_price1{
	margin-top: -25px;
    margin-left: 380px;
    font-size: 16px;
	font-weight: bold;
}
.semicolon8{
	margin-top: -18px;
    margin-left: 75px;
    font-weight: bold;
}
.quentity{
	margin-top: 30px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon9{
	margin-top: -18px;
    margin-left: 110px;
    font-weight: bold;
}
.quentity1 {
	margin-top: -25px;
    margin-left: 130px;
    font-size: 16px;
    font-weight: bold;
}
.grose{
	margin-top: -16px;
    margin-left: 290px;
    font-size: 16px;
}
.semicolon10{
	margin-top: -18px;
    margin-left: 75px;
    font-weight: bold;
}
.grose1{
	margin-top: -25px;
    margin-left: 380px;
    font-size: 16px;
    font-weight: bold;
}
.discount{
	margin-top: 10px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon11{
	margin-top: -18px;
    margin-left: 110px;
    font-weight: bold;
}
.discount1 {
	margin-top: -25px;
    margin-left: 130px;
    font-size: 16px;
    font-weight: bold;
}
.net_price{
	margin-top: -16px;
    margin-left: 290px;
    font-size: 16px;
}
.semicolon12{
	margin-top: -18px;
    margin-left: 75px;
    font-weight: bold;
}
.net_price1{
	margin-top: -25px;
    margin-left: 380px;
    font-size: 16px;
    font-weight: bold;
}
.payment{
	margin-top: 25px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon13{
	margin-top: -18px;
    margin-left: 75px;
    font-weight: bold;
}
.payment1{
	margin-top: -25px;
    margin-left: 130px;
    font-size: 16px;
    font-weight: bold;
}.due{
	margin-top: -16px;
    margin-left: 290px;
    font-size: 16px;
}
.due1{
	margin-top: -25px;
    margin-left: 380px;
    font-size: 16px;
    font-weight: bold;
}
.C_Signature{
	margin-top: 60px;
    margin-left: 5px;
    font-size: 16px;
    font-weight: bold;
}
.C_Signature1{
	margin-top: -22px;
    margin-left: 5px;
    border: 2px solid;
    width: 136px;
}
.A_Signature{
	margin-top: 0px;
    margin-left: 385px;
	font-size: 16px;
    font-weight: bold;
}
.A_Signature1{
	margin-top: -22px;
    margin-left: 379px;
    border: 2px solid;
    width: 143px;
}
.date{
	margin-top: -390px;
    margin-left: 5px;
    font-size: 16px;
    font-weight: bold;
}
.datepicker{
	margin-top: -17px;
    margin-left: 125px;
    font-size: 16px;
}
.button{
	margin-top: 1065px;
    margin-left: 835px;
}

</style>
</head>
<body>
	
	<section class="main">
	<div class="delta">
	<h1><center>Perfect Beauty BD</center></h1>
	</div>
	<div class="contact_number">
	<h3><center>Contact Number :01973-633163</center></h3>
	</div>
	<div class="mirpur">
	<h4><center>Mirpur, Dhaka-1207</center></h4><br>
	</div>
	<div class="image"><img src="perfect.png" height="15%" width="15%" alt="Ayub">
	</div>
	
	
<?php		{
		while($row=mysqli_fetch_assoc($result))	
		{
?>			
	
		<section class=>
		
		<div class="invoice_No"><th><?php echo ' Invoice ID <div class="semicolon1">:..............................</div>' ?></th></div><div class="invoice_No1"><td><?php echo $row['Invoice_No']; ?></td></div>
		<div class="Customer_Name"><th><?php echo ' Customer Name <div class="semicolon2">:............................................</div>' ?></th></div><div class="Customer_Name1"><td><?php echo $row['Customer_Name']; ?></td></div>
		<div class="Product_Name"><th><?php echo ' Product Name <div class="semicolon3">:.................................................</div>' ?></th></div><div class="Product_Name1"><td><?php echo $row['Product_Name']; ?></td></div><br>
		<div class="delivery"><th><?php echo ' Delivery Charge <div class="semicolon3">:.....................</div>' ?></th></div><div class="delivery1"><td><?php echo $row['Product_Name']; ?></td></div><br>
		<div class="Address"><th><?php echo ' Address <div class="semicolon4">:........................................................................................................</div>' ?></th></div><div class="Address1"><td><?php echo $row['Address']; ?></td></div>
		<div class="mobile_number"><th><?php echo '  Mobile Number <div class="semicolon5">:....................................</div>' ?></th></div><div class="m_number"><td><?php echo $row['Mobil_Number']; ?></td></div>
		<div class="unit_price"><th><?php echo ' Unit Price <div class="semicolon6">:........................................</div>' ?></th></div><div class="unit_price1"><td><?php echo $row['Unit_Price']; ?></td></div>
		<div class="quentity"><th><?php echo ' Quentity <div class="semicolon7">:....................................</div>' ?></th></div><div class="quentity1"><td><?php echo $row['Quentity']; ?></td></div>
		<div class="grose"><th><?php echo ' Grose Price <div class="semicolon8">:........................................</div>' ?></th></div><div class="grose1"><td><?php echo $row['Grose_Price']; ?></td></div></br>
		<div class="discount"><th><?php echo ' Discount <div class="semicolon9">:....................................</div>' ?></th></div><div class="discount1"><td><?php echo $row['Discount']; ?></td></div>
		<div class="net_price"><th><?php echo ' Net Price <div class="semicolon10">:........................................</div>' ?></th></div><div class="net_price1"><td><?php echo $row['Net_Price']; ?></td></div>
		<div class="payment"><th><?php echo ' Payment <div class="semicolon11">:....................................</div>' ?></th></div><div class="payment1"><td><?php echo $row['Payment']; ?></td></div>
		<div class="due"><th><?php echo ' Due <div class="semicolon12">:........................................</div>' ?></th></div><div class="due1"><td><?php echo $row['Due']; ?></td></div>
		<div class="C_Signature">Customer Signature</div>
		<div class="C_Signature1"></div>
		<div class="A_Signature">Authorize Signature</div>
		<div class="A_Signature1"></div>
		<div class="date"><th><?php echo ' Date:' ?></th></div><div class="datepicker"><td><?php echo $row['Date']; ?></td></div>
		
<?php

	}
}
?>
<?php		
}else{
	echo "Not Connected";
}
?>

</section>
<div class="button">
	<button type="button" onclick="print()">Print</button></div>
</body>
</html>