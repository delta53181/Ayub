
<!DOCTYPE lang="en-US">
    <html>

    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="UTF-8">
		
        <title>যোগাযোগ &#8211; Delta Institute of Technology</title>
<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/softtech-it.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.15"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='http://softtech-it.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='fb-messenger-style-css'  href='http://softtech-it.com/wp-content/plugins/fb-messenger/css/style.css?ver=4.9.15' type='text/css' media='all' />
<link rel='stylesheet' id='wp-video-grid-lighbox-style-css'  href='http://softtech-it.com/wp-content/plugins/video-grid/css/wp-video-grid-lighbox-style.css?ver=4.9.15' type='text/css' media='all' />
<link rel='stylesheet' id='vl-box-grid-css-css'  href='http://softtech-it.com/wp-content/plugins/video-grid/css/vl-box-grid-css.css?ver=4.9.15' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='http://softtech-it.com/wp-content/themes/SoftTechIT/css/bootstrap.min.css?ver=4.9.15' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='http://softtech-it.com/wp-content/themes/SoftTechIT/css/font-awesome.min.css?ver=4.9.15' type='text/css' media='all' />
<link rel='stylesheet' id='softtechit-stylesheet-css'  href='http://softtech-it.com/wp-content/themes/SoftTechIT/style.css?ver=4.9.15' type='text/css' media='all' />
<link rel='stylesheet' id='rpt-css'  href='http://softtech-it.com/wp-content/plugins/dk-pricr-responsive-pricing-table/inc/css/rpt_style.min.css?ver=4.9.15' type='text/css' media='all' />
<script type='text/javascript' src='http://softtech-it.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/plugins/video-grid/js/vl-grid-js.js?ver=4.9.15'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/plugins/video-grid/js/v_grid.js?ver=4.9.15'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/themes/SoftTechIT/js/jquery-ui.min.js?ver=4.9.15'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/themes/SoftTechIT/js/custom.js?ver=4.9.15'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/plugins/dk-pricr-responsive-pricing-table/inc/js/rpt.min.js?ver=4.9.15'></script>
<link rel='https://api.w.org/' href='http://softtech-it.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://softtech-it.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://softtech-it.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.15" />
<link rel="canonical" href="http://softtech-it.com/contact/" />
<link rel='shortlink' href='http://softtech-it.com/?p=13' />
<link rel="alternate" type="application/json+oembed" href="http://softtech-it.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fsofttech-it.com%2Fcontact%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://softtech-it.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fsofttech-it.com%2Fcontact%2F&#038;format=xml" />
			<meta property="fb:pages" content="1532418280146533" />
			<link rel="apple-touch-icon" sizes="180x180" href="/wp-content/uploads/fbrfg/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/wp-content/uploads/fbrfg/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/wp-content/uploads/fbrfg/favicon-16x16.png">
<link rel="manifest" href="/wp-content/uploads/fbrfg/site.webmanifest">
<link rel="mask-icon" href="/wp-content/uploads/fbrfg/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" href="/wp-content/uploads/fbrfg/favicon.ico">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="msapplication-config" content="/wp-content/uploads/fbrfg/browserconfig.xml">
<meta name="theme-color" content="#ffffff">
<!-- WordPress Facebook Integration Begin -->

<script type='text/javascript'>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
</script>

<script>
fbq('init', '212884919066594', {}, {
    "agent": "wordpress-4.9.15-1.7.7"
});

fbq('track', 'PageView', {
    "source": "wordpress",
    "version": "4.9.15",
    "pluginVersion": "1.7.7"
});
</script>
<!-- DO NOT MODIFY -->
<!-- WordPress Facebook Integration end -->
    
<!-- Facebook Pixel Code -->
<noscript>
<img height="1" width="1" style="display:none" alt="fbpx"
src="https://www.facebook.com/tr?id=212884919066594&ev=PageView&noscript=1"/>
</noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->
    
<!-- BEGIN ExactMetrics v5.3.5 Universal Analytics - https://exactmetrics.com/ -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-118259182-1', 'auto');
  ga('send', 'pageview');
</script>
<!-- END ExactMetrics Universal Analytics -->
    </head>

    <body class="page-template page-template-fullwidth-page page-template-fullwidth-page-php page page-id-13" >
	
		    <div class="sticky-header fixed">
        <div class="container">
            <div class="container row">
                <div class="col-md-3">
                    <div class="logo">
                         <a href="http://softtech-it.com"> <img src="http://softtech-it.com/wp-content/uploads/2018/02/softtech-it-white.png" alt="Logo"> </a>
                        <a class="menu-bar"> <i class="fa fa-bars"> </i> </a>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="main-menu">

                        <div class="menu-main-menu-container"><ul id="menu-main-menu" class="menu"><li id="menu-item-7" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-7"><a href="http://softtech-it.com/">হোম</a></li>
<li id="menu-item-26" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-26"><a href="http://softtech-it.com/about-us/">আমাদের সম্পর্কে</a></li>
<li id="menu-item-24" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-24"><a href="#">কোর্সসমূহ</a>
<ul class="sub-menu">
	<li id="menu-item-21" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="http://softtech-it.com/wordpress-course-in-bangladesh/">অ্যাডভান্সড ওয়ার্ডপ্রেস ডেভেলপমেন্ট</a></li>
	<li id="menu-item-130" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-130"><a href="http://softtech-it.com/graphic-design-course-in-bangladesh/">প্রফেশনাল ক্রিয়েটিভ গ্রাফিক ডিজাইন</a></li>
	<li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a href="http://softtech-it.com/online-course/">ওয়ার্ডপ্রেস অনলাইন কোর্স</a></li>
</ul>
</li>
<li id="menu-item-23" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-23"><a href="http://softtech-it.com/seminar/">সেমিনার</a></li>
<li id="menu-item-158" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-158"><a href="http://softtech-it.com/%e0%a6%b8%e0%a7%87%e0%a6%ac%e0%a6%be-%e0%a6%b8%e0%a6%ae%e0%a7%82%e0%a6%b9/">সেবা সমূহ</a>
<ul class="sub-menu">
	<li id="menu-item-160" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-160"><a href="http://softtech-it.com/web-design-in-bangladesh/">ওয়েবসাইট ডেভেলপমেন্ট</a></li>
</ul>
</li>
<li id="menu-item-22" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-13 current_page_item menu-item-22"><a href="http://softtech-it.com/contact/">যোগাযোগ</a></li>
<li id="menu-item-60" class="active menu-item menu-item-type-post_type menu-item-object-page menu-item-60"><a href="http://softtech-it.com/successful-freelancers-in-bangladesh/">সফল যারা</a></li>
</ul></div>                    </div>
                </div>
            </div>
        </div>
    </div>
	

        <!-- Header Area -->
        <div class="header-area-bg-single">
            <div class="header-area-single">
                <div class="top-area">
            <div class="container">
                <div class="top-content">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="top-content-one top-content-icon">
                                <p> <i class="fa fa-wordpress"></i>১৮০৮ এবং ১৮০৯ তম ব্যাচে ভর্তি চলছে  </p> <span> </span>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="top-content-two top-content-icon">
                                <p> <i class="fa fa-map-marker"></i> সকাল ০৯.০০ - বিকাল ০৫.০০ (অফিস)   </p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="top-content-three top-content-icon">
                                <p> <i class="fa fa-phone-square"></i> ০১৩১৯-৫১১০০৮, ০১৩১৯-৫১১০০৯  </p>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="top-social-icons">
                                <ul>
                                    <li><a title="Facebook Page" target="_blank" href="http://facebook.com/softtechitinstitute"> <i class="fa fa-facebook"></i> </a></li>
                                    <li><a title="Twitter Profile" target="_blank" href="http://twitter.com/softtechitinst"> <i class="fa fa-twitter"></i> </a></li>
                                    <li><a title="Linkedin Profile" target="_blank" href="#"> <i class="fa fa-linkedin"></i> </a></li>
                                    <li><a title="Youtube Channel" target="_blank" href="http://youtube.com/softtechit"> <i class="fa fa-youtube"></i> </a></li>
                                    <li><a title="Facebook Group" target="_blank" href="http://facebook.com/groups/softtechit"> <i class="fa fa-facebook-square"></i> </a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                <div class="header-content">
                    <div class="container">
                        <div class="header-main">
                            <div class="header-content">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="logo">
                                           
											 <a href="http://softtech-it.com"> <img src="http://softtech-it.com/wp-content/uploads/2018/02/SoftTech-IT-logo.png" alt="Logo"> </a>
                                            <a class="menu-bar"> <i class="fa fa-bars"> </i> </a>
                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="main-menu">

                                            <div class="menu-main-menu-container"><ul id="menu-main-menu-1" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-7"><a href="http://softtech-it.com/">হোম</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-26"><a href="http://softtech-it.com/about-us/">আমাদের সম্পর্কে</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-24"><a href="#">কোর্সসমূহ</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="http://softtech-it.com/wordpress-course-in-bangladesh/">অ্যাডভান্সড ওয়ার্ডপ্রেস ডেভেলপমেন্ট</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-130"><a href="http://softtech-it.com/graphic-design-course-in-bangladesh/">প্রফেশনাল ক্রিয়েটিভ গ্রাফিক ডিজাইন</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a href="http://softtech-it.com/online-course/">ওয়ার্ডপ্রেস অনলাইন কোর্স</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-23"><a href="http://softtech-it.com/seminar/">সেমিনার</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-158"><a href="http://softtech-it.com/%e0%a6%b8%e0%a7%87%e0%a6%ac%e0%a6%be-%e0%a6%b8%e0%a6%ae%e0%a7%82%e0%a6%b9/">সেবা সমূহ</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-160"><a href="http://softtech-it.com/web-design-in-bangladesh/">ওয়েবসাইট ডেভেলপমেন্ট</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-13 current_page_item menu-item-22"><a href="http://softtech-it.com/contact/">যোগাযোগ</a></li>
<li class="active menu-item menu-item-type-post_type menu-item-object-page menu-item-60"><a href="http://softtech-it.com/successful-freelancers-in-bangladesh/">সফল যারা</a></li>
</ul></div>                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Header Area -->

<div class="single-page-area">
	<div class="container">
							<div class="single-page">
						<div class="single-page-title">
							<h2>
								<a href="http://softtech-it.com/contact/"> যোগাযোগ </a>
							</h2>
							<h3>
								ফ্রিল্যান্সিং সংক্রান্ত যেকোনো সমস্যা সমাধানের জন্য চলে আসুন আমাদের অফিসে							</h3>
						</div>
						<div class="row">
<div class="col-md-5">
<div class="contact-address">
<h3> ডেলটা ইনষ্টিটিউট অফ টেকনোলজি </h3>
<p class="icon-address"> <i class="fa fa-map-marker"> </i>  বঙ্গবন্ধু হাই-টেক সিটি, কালিয়াকৈর, গাজীপুর। </p>
<p class="icon-address"> <i class="fa fa-clock-o"> </i> <b>   অফিস সময়  </b>  <span>  সকাল ০৯.০০ - বিকাল ০৫.০০ টা </span>  </p>
<p><p class="icon-address"> <i class="fa fa-phone-square"> </i> <b>   ফোন নম্বর  </b>  <span> ০১৩১৯-৫১১০০৮, ০১৩১৯-৫১১০০৯ </span>  </p>
<p><p class="icon-address"> <i class="fa fa-envelope-o"> </i>  <b>  ইমেল করুন </b>  <span> deltainstituteoftechnology@gmail.com </span>  </p>
<p><p class="icon-address"> <i class="fa fa-globe"></i>  <b>  আমাদের ওয়েবসাইট </b>  <span> www.kaliakoir-delta.com </span>  </p>
</div>
</div>
<div class="col-md-7">
<div class="contact-form">
<h3> যোগাযোগ করুন </h3>
<p class="text-danger">বিঃদ্রঃ বাম পাশে ঠিকানা এবং ফোন নাম্বার দেয়া আছে</p>
<div role="form" class="wpcf7" id="wpcf7-f28-p13-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="/contact/#wpcf7-f28-p13-o1" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="28" />
<input type="hidden" name="_wpcf7_version" value="5.0.3" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f28-p13-o1" />
<input type="hidden" name="_wpcf7_container_post" value="13" />
</div>
<p><span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="আপনার নাম (আবশ্যিক)" /></span> </p>
<p>    <span class="wpcf7-form-control-wrap tel-501"><input type="tel" name="tel-501" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel" aria-required="true" aria-invalid="false" placeholder="ফোন নাম্বার" /></span></p>
<p>    <span class="wpcf7-form-control-wrap email-233"><input type="email" name="email-233" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-email" aria-invalid="false" placeholder="ইমেইল অ্যাড্রেস" /></span></p>
<p>    <span class="wpcf7-form-control-wrap your-subject"><input type="text" name="your-subject" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="ম্যাসেজের বিষয়" /></span> </p>
<p>    <span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="আপনার ম্যাসেজ এখানে বিস্তারিত লিখুন"></textarea></span> </p>
<p><input type="submit" value="পাঠান" class="wpcf7-form-control wpcf7-submit" /></p>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div></div>
</div>
</div>
<div class="google-map">
<img src="/wp-content/uploads/2019/10/map-1.png" alt="" width="1365" height="449" class="alignnone size-full wp-image-51" />
</div>
					</div>
					</div>
</div>

<!-- Footer Area -->
    <div class="footer-area-background">
        <div class="widget-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="widget-style">
                            <div class="my-widget-style"><h2>ডেলটা ইনষ্টিটিউট অফ টেকনোলজি</h2>			<div class="textwidget"><p><img src="delta 1.jpg" alt="" width="300" height="87" class="alignnone size-medium wp-image-30" /></p>
<p>ডেলটা ইনষ্টিটিউট অফ টেকনোলজি আইটির একটি অঙ্গ প্রতিষ্ঠান । আমাদের প্রধান উদ্দেশ্য বঙ্গবন্ধু হাই-টেক সিটিতে সর্ববৃহত ফ্রীল্যান্সারস কমিউনিটি তৈরী করা । আমাদের সকল কোর্স ৬ মাস মেয়াদী এবং ৫ মাস কাজ শেখার পর এক মাস প্র্যাক্টিকাল কাজ করার মাধ্যমে স্টুডেন্টদেরকে এক্সপার্ট করে তোলা হয় ।</p>
</div>
		</div>                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="widget-style widget-another">
                            <div class="my-widget-style"><h2>ডেলটা ইনষ্টিটিউট অফ টেকনোলজি লিংকস</h2>			<div class="textwidget"><ul>
<li><a href="//www.facebook.com/Delta6262" target="_blank" rel="noopener">ফেইসবুক পেইজ</a></li>
<li><a href="https://www.facebook.com/groups/282844492513638" target="_blank" rel="noopener">ফেইসবুক গ্রুপ</a></li>
<li><a href="http://youtube.com/softtechit" target="_blank" rel="noopener"> ইউটিউব চ্যানেল</a></li>
<li><a href="#" target="_blank" rel="noopener"> কোর্সসমূহ </a></li>
<li><a href="http://softtech-it.com/wordpresss-course-in-bangladesh/" target="_blank" rel="noopener"> ওয়ার্ডপ্রেস কোর্স </a></li>
<li><a href="http://softtech-it.com/online-course/" target="_blank" rel="noopener"> অনলাইন কোর্স </a></li>
<li><a href="http://softtech-it.com/seminar/" target="_blank" rel="noopener">সফটটেক আইটি সেমিনার</a></li>
<li><a href="http://softtech-it.com/contact/" target="_blank" rel="noopener"> যোগাযোগ </a></li>
</ul>
</div>
		</div>                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="widget-style">
                            <div class="my-widget-style"><h2>যোগাযোগ করুন</h2>			<div class="textwidget"><p><i class="fa fa-map-marker"> </i> বঙ্গবন্ধু হাই-টেক সিটি, কালিয়াকৈর, গাজীপুর।</p>
<p><i class="fa fa-phone-square"> </i> ০১৩১৯-৫১১০০৮, ০১৩১৯-৫১১০০৯</p>
<p><i class="fa fa-envelope-o"> </i> deltainstituteoftechnology@gmail.com</p>
<p><i class="fa fa-globe"></i> www.kaliakoir-delta.com</p>
</div>
		</div>                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-area">
            <div class="container">
                <div class="footer">
                    <p> কপিরাইট &copy;  ডেলটা ইনষ্টিটিউট অফ টেকনোলজি - সর্বসত্ত্ব সংরক্ষিত  </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Area -->
    <a href="#" class="scrolltotop"> <i class="fa fa-angle-up"></i> </a>
    <!-- FB Messenger -->
<div id="fbMsg">
	<img data-remodal-target="fb-messenger" src="http://softtech-it.com/wp-content/plugins/fb-messenger/images/fb-messenger.png">
</div>

<div class="remodal" data-remodal-id="fb-messenger">
	<div class="fb-page" data-tabs="messages , events" data-href="http://facebook.com/softtechitinstitute" data-width="310" data-height="330" data-href="http://facebook.com/softtechitinstitute" data-small-header="true"  data-hide-cover="false" data-show-facepile="true" data-adapt-container-width="true">
		<div class="fb-xfbml-parse-ignore">
			<blockquote>Loading...</blockquote>
		</div>
	</div>
	</div>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.6";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<!-- End FB Messenger -->
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/softtech-it.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}}};
/* ]]> */
</script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.0.3'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-content/plugins/fb-messenger/js/index.js?ver=4.9.15'></script>
<script type='text/javascript' src='http://softtech-it.com/wp-includes/js/wp-embed.min.js?ver=4.9.15'></script>
	

</body>

</html>
<!--Generated by Endurance Page Cache-->