<?php
	$conn=mysqli_connect("localhost","root","");
	mysqli_select_db($conn,"delta_institute_of_technology");
	
?>
<!doctype html>
<html>
<head>
<meta charset="utf8">
<title>একজন ছাত্র-ছাত্রীর রিপোর্ট</title>
<link type="text/css" rel="stylesheet" href="style4.css"></link>
<link rel="stylesheet" href="css/css1.css">
  <link rel="stylesheet" href="resources/demos/style.css">
  <script src="js/js1.js"></script>
  <script src="js/js2.js"></script>


  <script>
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true,
	  dateFormat:'y-m-d'
	 });
  } );
  </script>
  
  
  </head>
  <section class="company_title">
<marquee>
<h1>ডেলটা ইনষ্টিটিউট অফ টেকনোলজি </h1>
</marquee>
</section>


<section class="student_information">
<table class="text" border="1">
	 <div class="logo">
	<img src="delta 2.jpg" width="5%" height="5%" alt="ayub">
	</div>
	<div class="delta">
	<h1><center>Delta Institute of Technology</center></h1>
	</div>
	<div class="bangabandhu">
	<h3><center>Bangabandhu Hi-Tech City</center></h3>
	</div>
	<div class="kaliakoir">
	<h4><center>Kaliakoir, Gazipur.</center></h4><br>
	</div>
	<div class="text_area" id="Print">
	<table class="text" border="1">
	<form action="student_admission_Report.php" Method="POST" cnctype="multipart/form-data" class="form_area">
	<h1><center> </center></h1>
	<div class="id">
	<b>Student ID :</b><input class="id1" type="text" name="ID_Number" placeholder=" Student ID ">
	</div>
	<div class="subject">
	<b>Subject:</b>

	<select class="subject1" name="Subject_Name"> <option value="1"> Select </option>
									<option value="Basic Office Application">Basic Office Application</option>
									<option value="Responsiv Web Design">Responsiv Web Design</option>
									<option value="Web Development">Web Development</option>
									<option value="Graphics Design">Graphics Design</option>
									<option value="PHP + Laravel">PHP + Laravel</option>
									<option value="Wordpress Theme Customization">Wordpress Theme Customization</option>
									<option value="Software Development">Software Development</option>
									<option value="English Spoken">English Spoken</option>
									<option value="Others">Others</option>
													
											</select>
											</div><br><br>
	<div class="btn">
	<input type="submit" class="bbbttt" name="Search" value="Search">
	
	</div>
	</div>
	</form>
	</table>
	
<style>
*{
	margin: 0px; padding: 0px;
}
.company_title{
	width:501px;
	height:37px;
	background-color:Green;
	margin: 0 auto;
	border-radius: 8px;
	border: 3px solid blue;
}
.student_information{
	background-color: Orange;
    border: 3px solid blue;
    border-radius: 12px;
    height: 251px;
    margin: 10px auto 0;
    padding-top: 20px;
    text-align: center;
    width: 501px;
}
.company_title h1{
	color: white;
	text-align: center;
	font-size:30px;
	text-align:suttonyMJ;
}
.company_title h2{
	color: white;
	text-align: center;
	font-size:20px;
}
.company_title h3{
	color: white;
	text-align: center;
	font-size:20px;
}
.logo{
	margin-top: -15px;
	margin-left: -438px;
}
.delta{
	color: Green;
	text-align: center;
	font-size:20px;
	margin-top: -51px;
}
.bangabandhu{
	color: black;
	text-align: center;
	font-size:18px;
}
.kaliakoir{
	color: black;
	text-align: center;
	font-size:15px;
}

.text_area{
	text-align: center;
}
.id{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left: 2px;
	margin-left:-31px;
	font-size: 25px;
}
.id1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 253px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 10px;
}
.subject{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left: 2px;
	margin-left:14px;
	font-size: 25px;
}
.subject1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
}
</style>
</body>
</html>