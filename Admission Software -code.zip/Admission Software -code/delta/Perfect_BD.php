<?php
$conn=mysqli_connect("localhost","root","");
	mysqli_select_db($conn," ict_solution_and_comper_institute");
?>
<html>
<head>
<meta charset="utf-8">
<title> ভর্তি ফরম </title>
  <link rel="stylesheet" href="resources/demos/style.css">
  <script src="js/js1.js"></script>
  <script src="js/js2.js"></script>
  <script>
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true
    });
  } );
  </script>
<style>
*{
	margin: 0px; padding: 0px;
}
.company_title{
	width:1000px;
	height:37px;
	background-color:Green;
	margin: 0 auto;
	border-radius: 8px;
	border: 3px solid blue;
}
.perfect_bd{
	background-color: #FF00FF;
    border: 3px solid blue;
    border-radius: 12px;
    height: 1200px;
    margin: 10px auto 0;
    padding-top: 20px;
    text-align: center;
    width: 1000px;
}
.company_title h1{
	color: white;
	text-align: center;
	font-size:30px;
}
.company_title h2{
	color: white;
	text-align: center;
	font-size:20px;
}
.company_title h3{
	color: white;
	text-align: center;
	font-size:20px;
}
.logo{
	width: 100px;
	height: 0px;
	margin-top: -15px;
	margin-left: 14px;
}
.delta{
	color: White;
	text-align: center;
	font-size:40px;
}
.bangabandhu{
	color: black;
	text-align: center;
	font-size:35px;
}
.kaliakoir{
	color: black;
	text-align: center;
	font-size:30px;
}
.asmission{
	color: red;
	text-align: center;
	font-size:40px;
}

.application{
	text-align: left;
	margin-top: 0px;
	margin-left: ;
	font-size: 25px;
}
.application1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	font-size: 16px;
}
.duration{
    border-radius: 10px;
    margin-top: -35px;
    margin-left: ;
    font-size: 23px;

}
.cours{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 220px;
	height: 35px;
	font-size: 16px;
}
.id_number{
	text-align: left;
	margin-top:10px;
	margin-left: 5px;
	font-size: 25px;
}
.id1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	font-size: 16px;
}
.Session{
	border-radius:10px;
	margin-top: -35px;
	margin-left: 612px;
	font-size: 25px;
}
.Session1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 220px;
	height: 35px;
	font-size: 16px;
}
.students_name{
    text-align: left;
	border-radius:10px;
	margin-top: 9px;
	font-size: 25px;
}
.s_name {
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	margin-left: 14px;
	margin-top: -28px;
	font-size: 16px;
}
.english{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	margin-left: 213px;
	margin-top: 0px;
	font-size: 16px;
}
.fathers_name{
	text-align: left;
    margin-top:10px;
	margin-left:5px;
	font-size: 25px;
}
.f_name{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	margin-left: 3px;
	margin-top: -28px;
	font-size: 16px;
}
.mothers_name{
	margin-left:-31px;
	margin-top: 10px;
	font-size: 25px;
}
.m_name{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	margin-left: -6px;
	margin-top: -28px;
	font-size: 16px;
}
.mailing_address{
	text-align: left;
    margin-top:10px;
	margin-left: 5px;
	font-size: 23px;
}
.m_address{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	margin-left: 8px;
	margin-top: -28px;
	font-size: 16px;
}
.permanent_address{
	text-align: left;
	margin-top:14px;
	margin-left: 5px;
	font-size: 20px;
}
.p_address{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 754px;
	height: 35px;
	margin-left: 8px;
	margin-top: -28px;
	font-size: 16px;
}
.religion{
    text-align: left;
	margin-top:10px;
	margin-left: 5px;
	font-size: 25px;
}
.religion1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
	margin-left: 207px;
	margin-top: -30px;

}
.gender{
	border-radius: 10px;
    margin-top: -32px;
    font-size: 25px;
    width: 717px;
    margin-left: 315px;
}
.gender1{
	border: 2px;
    solid: black;
    border-radius: 7px;
    width: 240px;
    height: 35px;
    font-size: 16px;
    margin-top: -31px;
    margin-left: 345px;
}
.d_birth{
    margin-top: 10px;
    margin-left: 5px;
    font-size: 25px;
    text-align: left;
}
.class{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
	margin-left: 23px;
}
.b_group{
	border-radius: 10px;
    font-size: 25px;
    margin-top: -36px;
    width: 964px;
    text-align: left;
    margin-left: 566px;
}
.blood{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
}
.nationality{
	margin-top: 10px;
    margin-left: 5px;
    font-size: 25px;
    text-align: left;
}
.nationality1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
	margin-left: 43px;
}
.national_id{
	text-align: left;
    border-radius: 10px;
    margin-top: -37px;
    margin-left: 579px;
    font-size: 25px;
	}
.n_id{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
}
.mobile_number{
	margin-left: 5px;
    margin-top: 10px;
    font-size: 25px;
    text-align: left;
}
.m_number{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
}
.email{
	border-radius: 10px;
    margin-top: -37px;
    font-size: 25px;
    text-align: left;
    margin-left: 641px;
}
.e_phone{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	font-size: 16px;
}
.G_P_name{
	border-radius: -31px;
    margin-top: 10px;
    font-size: 25px;
    text-align: left;
    margin-left: 5px;
}
.G_name{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 300px;
	height: 35px;
	margin-left: 14px;
	margin-top: -28px;
	font-size: 16px;
}
.occupation{
    border-radius: 10px;
    font-size: 25px;
    width: 717px;
    margin-top: -34px;
    margin-left: 293px;
}
.occupation1{
	border: 2px;
    solid: black;
    border-radius: 7px;
    width: 240px;
    height: 35px;
    font-size: 16px;
    margin-top: -29px;
    margin-left: 386px;
}
.relation{
    border-radius: -31px;
    margin-top: 10px;
    font-size: 25px;
    text-align: left;
    margin-left: 5px;
}
.relation1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 240px;
	height: 35px;
	margin-left: 207px;
	margin-top: -28px;
	font-size: 16px;
}
.g_mobile_number{
    border-radius: 10px;
    font-size: 25px;
    width: 717px;
    margin-top: -35px;
    margin-left: 259px;
}
.g_m_number{
	border: 2px;
    solid: black;
    border-radius: 7px;
    width: 205px;
    height: 35px;
    font-size: 16px;
    margin-top: -29px;
    margin-left: 485px;
}
.g_address{
	margin-top: 10px;
    font-size: 25px;
    margin-left: 5px;
    text-align: left;
}
.g_address1{
	    border: 2px;
    solid: black;
    border-radius: 7px;
    width: 754px;
    height: 35px;
    margin-left: 103px;
    margin-top: -28px;
    font-size: 16px;
}
.accademic{
	text-align: left;
	margin-left: 5px;
	margin-top: 20px;
	font-size: 25px;
}
.examination{
	margin-top: 16px;
	margin-right: 770px;
	font-size: 20px;
}
.e_name{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 192px;
	height: 35px;
	font-size: 16px;
	margin-top: 7px;
}
.subject{
	margin-top: -65px;
	margin-right: 404px;
	font-size: 20px;
}
.s_group{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 161px;
	height: 35px;
	font-size: 16px;
	margin-top: 7px;
}
.board{
	margin-top: -65px;
	margin-right: 100px;
	font-size: 20px;
}
.board1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 130px;
	height: 35px;
	font-size: 16px;
	margin-top: 7px;
}
.year{
	margin-top: -65px;
	margin-right: -194px;
	font-size: 20px;
}
.year1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	font-size: 16px;
	margin-top: 7px;
}
.exam{
	margin-top: -65px;
	margin-right: -508px;
	font-size: 20px;
}
.exam1{
	order: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	font-size: 16px;
	margin-top: 7px;
}
.cgpa{
	margin-top: -65px;
	margin-right: -820px;
	font-size: 20px;
}
.cgpa1{
	order: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	font-size: 16px;
	margin-top: 7px;
}
.records{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 349px;
	height: 25px;
	margin-left: 135px;
	margin-top: -22px;
}
.photo_upload{
    padding-top: -5px;
    text-align: left;
	font-size: 25px;
	margin-top: -35px;
}
.photo upload{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 349px;
	height: 25px;
	
}
.date{
	text-align: right;
	border-radius: 10px;
	margin-top: -43px;
	margin-right: 28px;
	font-size: 25px;
}
.datepicker{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 138px;
	height: 35px;
	margin-top: 10px;
}
.btn {
    background-color: Red;
    margin-top: 11px;
    padding-bottom: 13px;
	height: 55px;
}

.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: black;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  cursor: pointer;
}

.button {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
  margin-right: 4px;
}

</style>
<body>
<section class="company_title">
<marquee>
<h1>Perfect Beauty BD</h1>
</marquee>
</section>


<section class="perfect_bd">
<form action="Perfect_BD.php" Method="POST" cnctype="multipart/form-data" class="form_area">
	<div class="logo">
	<img src="perfect.png" width="100px" height="100px" alt="ayub">
	</div>
	<div class="delta">
	<h1><center>Perfect Beauty BD</center></h1>
	</div>
	<div class="bangabandhu">
	<h3><center>Contact Number :01973-633163</center></h3>
	</div>
	<div class="kaliakoir">
	<h4><center>Mirpur, Dhaka-1207</center></h4><br>
	</div>
	<div class="asmission">
	<center>Salse Datilse</center>
	</div>
	<div class="id_number">
	<b>Invoice ID :</b> <input class="id1" type="text" name="Invoice_No" placeholder="আইডির নাম্বার">
	</div>
	<div class="Session">
	<b>Customer Name :</b> <input class="Session1" type="text" name="Customer_Name" placeholder="সেশন">
	</div>
	<div class="students_name">
	<b>Mobil Number :</b> <input class="s_name" type="text" name="Mobil_Number" placeholder="বাংলায় নাম">
	</div>
	<div class="fathers_name">
	<b>Address :</b> <input class="f_name" type="text" name="Address" placeholder="বাংলায় নাম">
	</div>
	<div class="mothers_name">
	<b>1 Product Name :</b> <input class="m_name" type="text" name="Product_Name_1" placeholder="বাংলায় নাম">
	</div>
	<b>2 Product Name :</b> <input class="m_name" type="text" name="Product_Name_2" placeholder="বাংলায় নাম">
	</div>
	<b>3 Product Name :</b> <input class="m_name" type="text" name="Product_Name_3" placeholder="বাংলায় নাম">
	</div>
	<b>4 Product Name :</b> <input class="m_name" type="text" name="Product_Name_4" placeholder="বাংলায় নাম">
	</div>
	<b>5 Product Name :</b> <input class="m_name" type="text" name="Product_Name_5" placeholder="বাংলায় নাম">
	</div>
	<b>6 Product Name :</b> <input class="m_name" type="text" name="Product_Name_6" placeholder="বাংলায় নাম">
	</div>
	<div class="mailing_address">
	<b>Unit Price :</b><input class="m_address" type="text" name="Unit_Price" placeholder="বর্তমান ঠিকানা">
	</div>
	<div class="permanent_address">
	<b>Quentity :</b><input class="p_address" type="text" name="Quentity" placeholder="স্থায়ী ঠিকানা">
	</div>
	<div class="d_birth">
	<b>Grose Price :</b> <input class="class" type="text" name="Grose_Price" placeholder="জন্ম তারিখ">
	</div>
	<div class=b_group>
	<b>Delivery Charge :</b> <input class="blood" type="text" name="Delivery_Charge" placeholder="রক্তের গ্রুপ">
	</div>
	<div class="nationality">
	<b>Discount :</b> <input class="nationality1" type="text" name="Discount" placeholder="জাতীয়তা">
	</div>
	<div class="national_id">
	<b>Net Payment :</b> <input class="n_id" type="text" name="Net_Payment" placeholder="জাতীয় পরিচয় পত্রের নাম্বার">
	</div>
	<div class="mobile_number">
	<b>Payment :</b> <input class="m_number" type="text" name="Payment" placeholder="মোবাইল নাম্বার">
	</div>	
	<div class="email">
	<b>Due :</b> <input class="e_phone" type="text" name="Due" placeholder="ইমেল আইডি">
	</div>	
	<div class="date">
	<b>Date :</b> <input class="datepicker" type="date" name="Sale_Date" placeholder="তারিখ">
	</div>
	<div class="btn">
	<input type="submit" class="button" name="submit" value="Save">
	
	</div>
</body>
</head>

</html>
<?php
if(isset($_POST["submit"]))
{
	mysqli_query($conn,"insert into perfect_beauty value ('$_POST[Sale_Date]','$_POST[Invoice_No]','$_POST[Customer_Name]','$_POST[Mobil_Number]','$_POST[Address]','$_POST[Product_Name_1]','$_POST[Product_Name_2]','$_POST[Product_Name_3]','$_POST[Product_Name_4]','$_POST[Product_Name_5]','$_POST[Product_Name_6]','$_POST[Unit_Price]','$_POST[Unit_Price]','$_POST[Grose_Price]','$_POST[Delivery_Charge]','$_POST[Discount]','$_POST[Net_Payment]','$_POST[Payment]','$_POST[Due]')");
}
?>