<html>
    <head>
		<meta charset="utf8">
        <title>My first PHP Website</title>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
	<style>
.main_header {
	width: 802px;
	border: 2px solid blue;
	margin: 0 auto;
	margin-bottom: 10px;
	text-decoration: none;
	margin-left: 306;
}

.left_side {
	background-color: beige;
	border: 1px solid blue;
	border-radius: 5px;
	float: left;
	height: 80%;
	padding: 5px;
	width: 17%;
	text-decoration-line: none;
	margin-left: 58px;
}
.left_side a {
	text-decoration:none;
}
.medile_side {
	background-color: beige;
	border: 1px solid blue;
	float: left;
	height: 80%;
	padding: 6px;
	width: 60%;
	margin-left: 6px;
}
.right_side {
	background-color: beige;
	border: 1px solid blue;
	float: left;
	height: 80%;
	padding: 1px;
	width: 15%;
	margin-left: 6px;
}
.btn {
  background-color: DodgerBlue;
  border: none;
  color: white;
  padding: 12px 16px;
  font-size: 16px;
  cursor: pointer;
	</style>
    <body>
	<a href="logout.php"><button class="btn"><i class="fa fa-logout"></i> Logout</button></a>
		<div class="main_header">
		
        <marquee style="font-family: Times New Roman; color: #FFFFFF" bgcolor= "blue" behavior="scoll" onmouseover="this.stop()"; onmouseout="this.start();"><?php
            echo "<h1><b>DELTA INSTITUTE OF TECHNOLOGY</b></h1>";
        ?>
		</marquee>
        </div>
		<hr/>
		<section>
			<div class="left_side">
				<a href="https://xampp-windows.en.softonic.com/download"><button class="btn"><i class="fa fa-home"></i> Home</button>
				<button class="btn"><i class="fa fa-bars"></i> Menu</button>
				<a href="logout.php"><button class="btn"><i class="fa fa-close"></i> Close</button></a>
				<a href="logout.php"><img src="Image/logout1.JPG" width="15%" hight="15%"></a>
				<a href="login.php"> Login Page </a><br/>
				<a href="student_information.php"> STUDENT INFORMATION</a><br/>
				<a href="testbdc.php"> testbdc</a><br/>
				<a href="Barcode_section.php"> Barcode Section </a>
			</div>
		</section>
		<section>
			<div class="medile_side">
			<div>
			<button >Salary Entry Form </button>
			</div>
			<div>
			<a href="school_header.php"><img src="BTEB.JPG" width="15%" hight="15%"></a>
			</div>
			<div>
			<button >Salary Entry Form Display</button>
			</div>
			<div>
			<a href="Salary_Entry_Form_Play_Display.php"><img src="Sharif.JPG" width="15%" hight="15%"></a>
			</div>
			
			</div>
		</section>
		<section>
			<div class="right_side">
			<marquee behavior="alternate" direction="up" height="500" scrollamount="1" onmouseover="this.stop();" onmouseout="this.start();" ><center><img src="sharif.JPG" width="60%" hight="60%"></center></marquee>
			</div>
		
			
		</section>
		<div id="footer">
				<span style="display: inline-block; padding-top: 7px; padding-left: 11px;">Welcome&nbsp;&nbsp;
				<div style="width: auto; float: right;">				
				<span style="display: inline-block; padding-top: 7px; padding-right: 11px;">&nbsp;&nbsp;<strong>
				<span id=tick2>
				</span>
				<script>
				function show2(){
				if (!document.all&&!document.getElementById)
				return
				thelement=document.getElementById? document.getElementById("tick2"): document.all.tick2
				var Digital=new Date()
				var hours=Digital.getHours()
				var minutes=Digital.getMinutes()
				var seconds=Digital.getSeconds()
				var dn="PM"
				if (hours<12)
				dn="AM"
				if (hours>12)
				hours=hours-12
				if (hours==0)
				hours=12
				if (minutes<=9)
				minutes="0"+minutes
				if (seconds<=9)
				seconds="0"+seconds
				var ctime=hours+":"+minutes+":"+seconds+" "+dn
				thelement.innerHTML=ctime
				setTimeout("show2()",1000)
				}
				window.onload=show2
				//-->
				</script>
				&nbsp;|&nbsp;<?php echo date("l F d, Y"); ?></strong></span>
				</div>
    </body>
</html> 