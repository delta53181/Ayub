<?php
$conn = mysqli_connect('localhost','root','','delta_money_receipt');
if ($conn) {
	if(isset($_POST['Search'])){
		$ID_Number=$_POST['ID_Number'];
		
		
				
		$sql= "select * from money_receipt where ID_Number='$ID_Number'";
		$result = mysqli_query($conn, $sql);
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf8">
<title>টাকা জমার রশিদ</title>
<link type="text/css" rel="stylesheet" href="style4.css"></link>
<link rel="stylesheet" href="css/css1.css">
  <link rel="stylesheet" href="resources/demos/style.css">
  <script src="js/js1.js"></script>
  <script src="js/js2.js"></script>
 <script>
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true,
	  dateFormat:"dd-mm-yy"
	  });
  } );
  </script>
  <script>
  function printRoutine(){
		printDiv("print_area");
	}
	
	function printDiv(Print) {
     var printContents = document.getElementById(Print).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

    window.print();
	
	  
	document.body.innerHTML = originalContents;
	
	 
}
  </script>
<style>

*{
	margin:0px; padding:0px;
}
.main{
	width:288px;	
	height:384px;	
	background-color: white;
	margin: 0 auto;	
	border-radius: 8px;	
	border:10px solid blue;
	margin-top: 10px;
}
.header{
	line-height: 230%;
    margin-top: 10px;
}
}
.header_text{
	line-height: 70%;
}
.image{
	text-align: center;
}
.delta{
	color: Green;
	text-align: center;
	font-size:15px;
	margin-top: -20px;
}
.bangabandhu{
	color: black;
	text-align: center;
	font-size:15px;
	margin-top: -15px;
}
.kaliakoir{
	color: black;
	text-align: center;
	font-size:15px;
	margin-top: -20px;
}
.admission{
	font-size: 20px;
    font-weight: bold;
    margin-top: -10px;
}
.date{
	margin-top: -42px;
    margin-left: 5px;
    font-size: 12px;
    font-weight: bold;
}
.datepicker{
	margin-top: -35px;
    margin-left: 35px;
    font-size: 12px;
    font-weight: bold;
}
.id_number{
	margin-top: -36px;
    margin-left: 120px;
    font-size: 12px;
    font-weight: bold;
}
.id1{
	margin-top: -36px;
    margin-left: 190px;
    font-size: 12px;
    font-weight: bold;
}
.students_name{
	margin-top: -15px;
    margin-left: 5px;
    font-size: 12px;
    font-weight: bold;
}
.s_name{
	margin-top: -36px;
    margin-left: 100px;
    font-size: 12px;
    font-weight: bold;
}
.fathers_name{
	margin-top: -15px;
    margin-left: 5px;
    font-size: 12px;
    font-weight: bold;
}
.colon1{
	margin-top: -36px;
    margin-left: 85px;
    font-size: 12px;
    font-weight: bold;
}
.f_name{
	margin-top: -36px;
    margin-left: 100px;
    font-size: 12px;
    font-weight: bold;
}
.mothers_name{
	margin-top: -15px;
    margin-left: 5px;
    font-size: 12px;
    font-weight: bold;
}
.colon2{
	margin-top: -36px;
    margin-left: 85px;
    font-size: 12px;
    font-weight: bold;
}
.m_name{
	margin-top: -36px;
    margin-left: 100px;
    font-size: 12px;
    font-weight: bold;
}
.cours{
	margin-top: -15px;
    margin-left: 5px;
    font-size: 12px;
    font-weight: bold;
}
.colon3{
	margin-top: -36px;
    margin-left: 85px;
    font-size: 12px;
    font-weight: bold;
}
.cours1{
	margin-top: -36px;
    margin-left: 100px;
    font-size: 12px;
    font-weight: bold;
}
.Session{
	margin-top: -15px;
    margin-left: 5px;
    font-size: 12px;
    font-weight: bold;
}
.colon4{
	margin-top: -36px;
    margin-left: 85px;
    font-size: 12px;
    font-weight: bold;
}
.Session1{
	margin-top: -36px;
    margin-left: 100px;
    font-size: 12px;
    font-weight: bold;
}
.month{
	margin-top: -15px;
    margin-left: 5px;
    font-size: 12px;
    font-weight: bold;
}
.colon5{
	margin-top: -36px;
    margin-left: 85px;
    font-size: 12px;
    font-weight: bold;
}
.month1{
	margin-top: -36px;
    margin-left: 100px;
    font-size: 12px;
    font-weight: bold;
}
.instalment{
	margin-top: -15px;
    margin-left: 5px;
    font-size: 12px;
    font-weight: bold;
}
.colon6{
	margin-top: -36px;
    margin-left: 85px;
    font-size: 12px;
    font-weight: bold;
}
.instalment1{
	margin-top: -36px;
    margin-left: 100px;
    font-size: 12px;
    font-weight: bold;
}
.amount{
	margin-top: -15px;
    margin-left: 5px;
    font-size: 12px;
    font-weight: bold;
}
.colon7{
	margin-top: -36px;
    margin-left: 85px;
    font-size: 12px;
    font-weight: bold;
}
.amount1{
	margin-top: -36px;
    margin-left: 100px;
    font-size: 12px;
    font-weight: bold;
}
.A_Signature{
	margin-top: 13px;
    margin-left: 5px;
    font-size: 12px;
    font-weight: bold;
}
.signature1{
	margin-top: -84px;
    margin-left: 12px;
}
.D_Signature{
	margin-top: -36px;
    margin-left: 160px;
}
.signature{
	margin-top: -60px;
    margin-left: 168px;
}
.qrcode{
	margin-top: -69px;
    margin-left: 24px;
}
.print{
	float: left;
	margin-top: -61px;
	margin-left: 816px;
}
</style>
</head>
<body>
	
	<section class="main">
	<div class="header">
	<div class="delta">
	<h1><center>Delta Institute of Technology</center></h1>
	</div>
	<div class="bangabandhu">
	<h3><center>Bangabandhu Hi-Tech City</center></h3>
	</div>
	<div class="kaliakoir">
	<h4><center>Kaliakoir, Gazipur.</center></h4>
	</div>
	<div class="image">
	<img src="delta.jpg" style=" width:50px; height:50px;" alt="Ayub"></div>
	<div class="qrcode">
	<img src="qrcode.png" style=" width:50px; height:50px;"  alt="Ayub"></div>
	<div class="admission">
	<center>Money Receipt</center>
	</div><br>
	
<?php		{
		while($row=mysqli_fetch_assoc($result))	
		{
?>	

		<div class="date"><th><?php echo ' Date:' ?></th></div><div class="datepicker"><td><?php echo $row['Admission_Date']; ?></td></div>
		<div class="id_number"><th><?php echo ' ID Number :' ?></th></div><div class="id1"><td><?php echo $row['ID_Number']; ?></td></div>
		<div class="students_name"><th><?php echo '  Student᾿s Name :' ?></th></div><div class="s_name"><td><?php echo $row['Students_Name']; ?></td></div>
		<div class="fathers_name"><th><?php echo '  Father᾿s Name <div class="colon1">:</div>' ?></th></div><div class="f_name"><td><?php echo $row['Fathers_Name']; ?></td></div>
		<div class="mothers_name"><th><?php echo ' Mother᾿s Name <div class="colon2">:</div>' ?></th></div><div class="m_name"><td><?php echo $row['Mothers_Name']; ?></td></div>
		<div class="cours"><th><?php echo ' Course Name <div class="colon3">:</div>' ?></th></div><div class="cours1"><td><?php echo $row['Admission_Name']; ?></td></div>
		<div class="Session"><th><?php echo ' Session <div class="colon4">:</div>' ?></th></div><div class="Session1"><td><?php echo $row['Session']; ?></td></div>
		<div class="month"><th><?php echo ' Month <div class="colon5">:</div>' ?></th></div><div class="month1"><td><?php echo $row['Month_Name']; ?></td></div>
		<div class="instalment"><th><?php echo ' Instalment <div class="colon6">:</div>' ?></th></div><div class="instalment1"><td><?php echo $row['Instalment']; ?></td></div>
		<div class="amount"><th><?php echo ' Amount <div class="colon7">:</div>' ?></th></div><div class="amount1"><td><?php echo $row['Amount_Tk']; ?></td></div>
		<div class="A_Signature"><th><?php echo '  Accounts Manager ' ?></div>
		<div class="signature1"><img src="signiture_1-removebg-preview.png" height="10%" width="30%" alt="Ayub"></div>
		<div class="D_Signature"><th><?php echo '  Managing Director ' ?></div>
		<div class="signature"><img src="signiture-removebg-preview.png" height="50%" width="60%" alt="Ayub"></div><br>
		
		
		
		</div>
<?php

	}
}
?>
<?php		
}else{
	echo "Not Connected";
}
?>

</section>
	<div class="print">
	<button type="button" onclick="print()">Print</button></br>
	</div>
</body>
</html>